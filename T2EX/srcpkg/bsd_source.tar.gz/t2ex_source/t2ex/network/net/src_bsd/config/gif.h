/*	$NetBSD: gif.h,v 1.1 2008/10/06 00:27:48 pooka Exp $	*/

/* dummy */
