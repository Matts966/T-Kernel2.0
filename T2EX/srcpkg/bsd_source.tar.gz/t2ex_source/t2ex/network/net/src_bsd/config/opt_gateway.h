/* option `GATEWAY' not defined */
