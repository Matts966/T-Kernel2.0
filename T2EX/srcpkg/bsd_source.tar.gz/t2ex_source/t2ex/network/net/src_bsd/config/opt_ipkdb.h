/* option `IPKDB' not defined */
/* option `IPKDBSECURE' not defined */
/* option `IPKDBKEY' not defined */
/* option `IPKDB_DP8390' not defined */
/* option `IPKDB_NE' not defined */
