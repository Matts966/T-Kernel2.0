/* option `POOL_LOGSIZE' not defined */
