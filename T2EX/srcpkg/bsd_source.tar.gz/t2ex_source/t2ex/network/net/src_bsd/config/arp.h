#define	NARP	1
#define	NNETATALK	0
