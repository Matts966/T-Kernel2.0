/* option `SOSEND_NO_LOAN' not defined */
