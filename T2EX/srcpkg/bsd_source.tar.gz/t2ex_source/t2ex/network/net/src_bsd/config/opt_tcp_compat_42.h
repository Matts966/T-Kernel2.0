/* option `TCP_COMPAT_42' not defined */
