/* option `SOMAXKVA' not defined */
