/* option `SB_MAX' not defined */
