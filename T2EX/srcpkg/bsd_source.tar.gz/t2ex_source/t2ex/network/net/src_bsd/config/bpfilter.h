/*	$NetBSD: bpfilter.h,v 1.1 2008/10/06 00:27:06 pooka Exp $	*/

/* dummy */
