/* option `DDB' not defined */
