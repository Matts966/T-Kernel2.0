/* option `HOSTZEROBROADCAST' not defined */
/* option `SUBNETSARELOCAL' not defined */
