/* option `POOL_DIAGNOSTIC' not defined */
