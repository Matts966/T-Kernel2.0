/* option `KTRACE' not defined */
