/* option `SOSEND_COUNTERS' not defined */
