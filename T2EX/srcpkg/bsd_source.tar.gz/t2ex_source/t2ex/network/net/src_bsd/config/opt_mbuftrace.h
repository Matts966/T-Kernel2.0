/* option `MBUFTRACE' not defined */
