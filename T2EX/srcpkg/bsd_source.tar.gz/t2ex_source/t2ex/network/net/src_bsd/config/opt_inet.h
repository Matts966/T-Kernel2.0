/* option `INET6_MD_CKSUM' not defined */
/* option `INET6' not defined */
/* option `INET' not defined */
