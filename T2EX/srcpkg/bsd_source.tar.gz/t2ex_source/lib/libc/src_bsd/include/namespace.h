/*	$OpenBSD: namespace.h,v 1.2 1996/08/19 08:28:08 tholo Exp $	*/

#define catclose	_catclose
#define catgets		_catgets
#define catopen		_catopen
#define err		_err
#define errx		_errx
#define strtoq		_strtoq
#define strtouq		_strtouq
#define sys_errlist	_sys_errlist
#define sys_nerr	_sys_nerr
#define sys_siglist	_sys_siglist
#define verr		_verr
#define verrx		_verrx
#define vwarn		_vwarn
#define vwarnx		_vwarnx
#define warn		_warn
#define warnx		_warnx
