/*
 * r4581nb spi inplement.
 * 
 * Copyright (c) 2011 UNL
 * Written by Lei Tan
 *
 * This code is licenced under the LGPL.
 *
 */

#ifndef __QEMU_R4581NB_H_
#define __QEMU_R4581NB_H_

#include "em1spi.h"

spi_slave *r4581nb_create();

#endif // __QEMU_R4581NB_H_