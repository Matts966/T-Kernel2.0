#include "i2c.h"

#define DEBUG_MAX7324 0

#if DEBUG_MAX7324
#define MAX7324_P_DBG(fmt, ...) printf("MAX7324:%s: " fmt, __FUNCTION__, ## __VA_ARGS__)
#else
#define MAX7324_P_DBG(fmt, ...) ((void)0)
#endif

void max7324_reset(i2c_slave *i2c);
i2c_slave *max7324_init(i2c_bus *i2c, uint8_t in_sla, uint8_t out_sla);
qemu_irq *max7324_gpio_in_get(i2c_slave *i2c);
void max7324_gpio_out_set(i2c_slave *i2c, int line, qemu_irq handler);
void max7324_int_out_Set(i2c_slave *i2c, qemu_irq handler);

typedef struct{
	uint8_t insla;
    uint8_t outsla;

    int step;
    uint8_t in_recv;
    uint8_t int_pend;
    
    uint8_t inlevel;
    uint8_t intrans;
    uint8_t intrans_pre;
    uint8_t inmask;
    
    uint8_t outlevel;
    
    qemu_irq handler[8];
    qemu_irq *gpio_in;
    qemu_irq int_handler;
} MAX7324Dev;

typedef struct {
    i2c_slave i2c;
    MAX7324Dev *dev;
} MAX7324State;

static const char out_default[16] = {
	0xf0,
	0xff,
	0xff,
	0xff,
	0xf0,
	0xff,
	0xff,
	0xff,
	0x00,
	0x0f,
	0x0f,
	0x0f,
	0xf0,
	0xff,
	0xff,
	0xff
};

void max7324_reset(i2c_slave *i2c)
{
    MAX7324State *s = FROM_I2C_SLAVE(MAX7324State, i2c);
    uint8_t diff, line;
    
    s->dev->step = 0;
    s->dev->in_recv = 0;
    s->dev->int_pend = 0;
    
    s->dev->inlevel = 0x0;
    s->dev->intrans = 0;
    s->dev->intrans_pre = 0;
    s->dev->inmask = 0xff;
    
    s->dev->outlevel = 0;
	for (diff = (out_default[s->dev->outsla & 0x0f] ^ s->dev->outlevel); diff; diff &= ~(1 << line)) {
        line = ffs(diff) - 1;
        if (s->dev->handler[line])
            qemu_set_irq(s->dev->handler[line], (out_default[s->dev->outsla & 0x0f] >> line) & 1);
    }
    s->dev->outlevel = out_default[s->dev->outsla & 0x0f];
}

static int max7324_rx(i2c_slave *i2c){
	MAX7324State *s = FROM_I2C_SLAVE(MAX7324State, i2c);
	uint8_t data;
	
	if(i2c->address == s->dev->insla){
		if(s->dev->step % 2 == 0){
			s->dev->intrans_pre = s->dev->intrans;
    		s->dev->intrans = 0;
    		s->dev->int_pend = 0;
			data = s->dev->inlevel;
		}
		else{
			data = s->dev->intrans_pre;
		}
	}
	else if(i2c->address == s->dev->outsla){
		data = s->dev->outlevel;
	}
	else{
		data = 0;
	}
	
	s->dev->step++;
	
	MAX7324_P_DBG(" 0x%02x read : 0x%02x\n", i2c->address, data);
	return data;
}

static int max7324_tx(i2c_slave *i2c, uint8_t data){
	MAX7324State *s = FROM_I2C_SLAVE(MAX7324State, i2c);
	uint8_t diff, line;
	
	MAX7324_P_DBG(" 0x%02x write : 0x%02x\n", i2c->address, data);
	if(i2c->address == s->dev->insla){
		s->dev->inmask = data;
		s->dev->intrans = 0;
		if(s->dev->int_handler){
			qemu_set_irq(s->dev->int_handler, 1);
		}
	}
	else if(i2c->address == s->dev->outsla){
		for (diff = (data ^ s->dev->outlevel); diff; diff &= ~(1 << line)) {
            line = ffs(diff) - 1;
            if (s->dev->handler[line])
                qemu_set_irq(s->dev->handler[line], (data >> line) & 1);
        }
        s->dev->outlevel = data;
	}
	
	return 0;
}

static void max7324_event(i2c_slave *i2c, enum i2c_event event)
{
    MAX7324State *s = FROM_I2C_SLAVE(MAX7324State, i2c);
    
	MAX7324_P_DBG(" 0x%02x event : 0x%02x\n", i2c->address, event);
    switch (event) {
    case I2C_START_SEND:
        break;
    case I2C_START_RECV:
    	if(s->dev->int_handler){
			qemu_set_irq(s->dev->int_handler, 1);
		}
    	s->dev->step = 0;
    	s->dev->in_recv = 1;
    	break;
    case I2C_FINISH:
    	if(s->dev->in_recv){
			if(s->dev->int_pend){
				if(s->dev->int_handler){
					qemu_set_irq(s->dev->int_handler, 0);
				}
				s->dev->int_pend = 0;
			}
			s->dev->in_recv = 0;
		}
    	break;
    default:
        break;
    }
}

static int max7324_slave_init(i2c_slave *i2c)
{
	MAX7324_P_DBG("Slave address:0x%02x\n", i2c->address);

	return 0;
}

static void max7324_gpio_set(void *opaque, int line, int level)
{
    MAX7324State *s = FROM_I2C_SLAVE(MAX7324State, opaque);
    if (line >= 8 || line  < 0)
        hw_error("bad GPIO line");
        
    if((s->dev->inlevel & (1 << line)) != (level << line)){
		if (level)
			s->dev->inlevel |=  (1 << line);
	    else
			s->dev->inlevel &= ~(1 << line);
		
		s->dev->intrans |= (1 << line);
		if(s->dev->inmask & (1 << line)){
			if(s->dev->in_recv){
				s->dev->int_pend = 1;
			}
			else{
				if(s->dev->int_handler){
					qemu_set_irq(s->dev->int_handler, 0);
				}
			}
		}
	}
}

i2c_slave *max7324_init(i2c_bus *i2c, uint8_t in_sla, uint8_t out_sla)
{
    MAX7324State *s;
    MAX7324Dev *dev = qemu_mallocz(sizeof(MAX7324Dev));
    
    // Create slave for input ports.
    s = FROM_I2C_SLAVE(MAX7324State, (i2c_slave*)i2c_create_slave(i2c, "max7324", in_sla));
    dev->insla = in_sla;
    s->dev = dev;
    
    dev->gpio_in = qemu_allocate_irqs(max7324_gpio_set, s, 8);
    
    // Create slave for output ports.
    s = FROM_I2C_SLAVE(MAX7324State, (i2c_slave*)i2c_create_slave(i2c, "max7324", out_sla));
    dev->outsla = out_sla;
    s->dev = dev;

    return (&s->i2c);
}

qemu_irq *max7324_gpio_in_get(i2c_slave *i2c)
{
    MAX7324State *s = (MAX7324State *) i2c;
    return s->dev->gpio_in;
}

void max7324_gpio_out_set(i2c_slave *i2c, int line, qemu_irq handler)
{
    MAX7324State *s = (MAX7324State *) i2c;
    if (line >= ARRAY_SIZE(s->dev->handler) || line  < 0)
        hw_error("bad GPIO line");

    s->dev->handler[line] = handler;
}

void max7324_int_out_Set(i2c_slave *i2c, qemu_irq handler){
	MAX7324State *s = (MAX7324State *) i2c;
	
	s->dev->int_handler = handler;
}

static I2CSlaveInfo max7324_info = {
    .qdev.name = "max7324",
    .qdev.size = sizeof(MAX7324State),
//    .qdev.vmsd = &vmstate_max7324,
    .init = max7324_slave_init,
    .event = max7324_event,
    .recv = max7324_rx,
    .send = max7324_tx
};

static void max7324_register_devices(void)
{
	i2c_register_slave(&max7324_info);
}

device_init(max7324_register_devices)