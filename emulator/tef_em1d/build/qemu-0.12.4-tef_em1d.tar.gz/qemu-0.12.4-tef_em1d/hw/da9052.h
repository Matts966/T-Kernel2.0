/*
 * da9052 PMIC dummy.
 * 
 * Copyright (c) 2011 UNL
 * Written by Lei Tan
 *
 * This code is licenced under the LGPL.
 *
 */

#ifndef __QEMU_DA9052_H_
#define __QEMU_DA9052_H_

#include "em1spi.h"

spi_slave *da9052_create(qemu_irq irq, int xmin, int xmax, int ymin, int ymax, int xchg);

#endif // __QEMU_DA9052_H_