#include "sysbus.h"
#include "qemu-char.h"

/* NOTE: DMA�������쐬���Ȃ�����,2 byte�A�N�Z�X�ł��Ȃ� */

#define FCR_FIFO			0x0001		/* FIFO�C�l�[�u��						*/
#define FCR_RFIFO_RESET		0x0002		/* ��MFIFO Reset						*/
#define FCR_XFIFO_RESET		0x0004		/* ���MFIFO Reset						*/
#define FCR_FIFO64			0x0020		/* FIFO�T�C�Y��64						*/
#define FCR_ITL_1			0x0000		/* 1 byte ITL */
#define FCR_ITL_2			0x0040		/* 4 bytes ITL */
#define FCR_ITL_3			0x0080		/* 8 bytes ITL */
#define FCR_ITL_4			0x00C0		/* 14 bytes ITL */

#define IER_MSI				0x0008		/* Enable Modem status interrupt */
#define IER_RLSI			0x0004		/* Enable receiver line status interrupt */
#define IER_THRI			0x0002		/* Enable Transmitter holding register int. */
#define IER_RDI				0x0001		/* Enable receiver data/timeout interrupt */

#define IIR_NO_INT			0x0001		/* No interrupts pending */
#define IIR_MSI				0x0000		/* Modem status interrupt */
#define IIR_THRI			0x0002		/* Transmitter holding register empty */
#define IIR_RDI				0x0004		/* Receiver data interrupt */
#define IIR_RLSI			0x0006		/* Receiver line status interrupt */
#define IIR_CTI  	  		0x000C    	/* Character Timeout Indication */
#define IIR_FE    	 		0x00C0    	/* Fifo enabled */

#define LCR_DLAB			0x0080		/* Divisor latch access bit */

#define MCR_LOOP			0x0010		/* Enable loopback test mode			*/
#define MCR_RTS				0x0002		/* RTS complement	 					*/
#define MCR_DTR				0x0001		/* DTR complement	 					*/

#define LSR_RFIFO_ERR		0x0080		/* ��MFIFO�G���[						*/
#define LSR_TEMT			0x0040		/* Transmitter empty */
#define LSR_THRE			0x0020		/* Transmit-hold-register empty */
#define LSR_BI				0x0010		/* Break���荞�݌��o					*/
#define LSR_FE				0x0008		/* Frame error indicator */
#define LSR_PE				0x0004		/* Parity error indicator */
#define LSR_OE				0x0002		/* Overrun error indicator */
#define LSR_DR				0x0001		/* Receiver data ready */
#define LSR_INT_ANY			0x001E		/* Any of the lsr-interrupt-triggering status bits */

#define MSR_DCD				0x0080		/* Data Carrier Detect */
#define MSR_RI				0x0040		/* Ring Indicator */
#define MSR_DSR				0x0020		/* Data Set Ready */
#define MSR_CTS				0x0010		/* Clear to Send */
#define MSR_DDCD			0x0008		/* Delta DCD */
#define MSR_TERI			0x0004		/* Trailing edge ring indicator */
#define MSR_DDSR			0x0002		/* Delta DSR */
#define MSR_DCTS			0x0001		/* Delta CTS */
#define MSR_ANY_DELTA		0x000F		/* Any of the delta bits! */

#define LCR_NUM_STOP2		0x0004		/* Number of stop bits					*/
#define LCR_PARITY_ENABLE	0x0008		/* Parity�@�\�L��						*/
#define LCR_PARITY_EVEN		0x0010		/* ����Parity�ݒ�						*/
#define LCR_PARITY_STICK	0x0020		/* �Œ�Parity�ݒ�						*/

#define HCR0_SW_RESET		0x0080		/* RBR/THR DLM DLL�ȊO�̃��W�X�^Reset	*/
#define HCR0_ACCESS_2BYTE	0x0020		/* 2�o�C�g�E���[�h/���C�g				*/
#define HCR0_RCV_TMO_DIS	0x0010		/* RBR/THR DLM DLL�ȊO�̃��W�X�^Reset	*/

#define HCR2_RFIFO_EMPTY	0x0080		/* Read Fifo Underrun					*/

#define HCR3_TFIFO_FULL		0x0080		/* Send Fifo Overrun					*/

#define XMIT_FIFO           0
#define RECV_FIFO           1
#define MAX_XMIT_RETRY      4
#define FIFO_MAX_LEN		64

#define DATA_LEN(s)			(3 - (s->regs[4] & 0x0003))
#define FIFO_ENABLE(s)		((s)->regs[3] & FCR_FIFO)

#define DEBUG_UART			0
#ifndef UART_P_DBG
#if DEBUG_UART
#define UART_P_DBG(fmt, ...) printf("UART:%s:%d " fmt, __FUNCTION__, __LINE__, ## __VA_ARGS__)
#else
#define UART_P_DBG(fmt, ...) ((void)0)
#endif
#endif


typedef struct QEMUTimer QemuTimer;

typedef struct SerialFIFO {
    uint8_t data[FIFO_MAX_LEN];
    uint8_t count;
    uint8_t itl;                        /* Interrupt Trigger Level */
    uint8_t tail;
    uint8_t head;
} SerialFIFO;

typedef struct
{
    SysBusDevice	busdev;

	int				fifo_size;
	SerialFIFO		recv_fifo;
	SerialFIFO		xmit_fifo;

	/* ���W�X�^ 													*/
	/* regs[1]  IER   ���荞��Enable���W�X�^						*/
	/* regs[2]  IIR   ���荞�ݎ��ʃ��W�X�^							*/
	/* regs[3]  FCR   FIFO���䃌�W�X�^								*/
	/* regs[4]  LCR   ���C�����䃌�W�X�^							*/
	/* regs[5]  MCR   ���f�����䃌�W�X�^							*/
	/* regs[6]  LSR   ���C��Status���W�X�^							*/
	/* regs[7]  MSR   ���f��Status���W�X�^							*/
	/* regs[8]  SCR   �X�N���b�`���W�X�^							*/
	/* regs[9]  DLL   baud rate generator�pdivisor�̏�ʃ��W�X�^	*/
	/* regs[10] DLM   baud rate generator�pdivisor�̉��ʃ��W�X�^	*/
	/* regs[11] HCR0  �n�[�h�E�F�A���䃌�W�X�^						*/
	/* regs[12] HCR2  ��MFIFO��ԃ��W�X�^							*/
	/* regs[13] HCR3  ���MFIFO��ԃ��W�X�^							*/
	/* regs[16] IRCR0 IrDA SIR�G���R�[�_/�f�R�[�_���䃌�W�X�^		*/
	/* regs[17] IRCR1 IrDA SIR��M�L���p���X�����W�X�^				*/
	/* regs[18] IRCR2 IrDA SIR���䃌�W�X�^2(�}�X�N���ԏ��8�r�b�g)	*/
	/* regs[19] IRCR3 IrDA SIR���䃌�W�X�^3(�}�X�N���Ԓ���8�r�b�g)	*/
	/* regs[20] IRCR4 IRDA SIR���䃌�W�X�^4(�}�X�N���ԉ���8�r�b�g)	*/
	uint16_t		regs[21];
    uint16_t		rbr;				/* receive register */
    uint16_t		thr;				/* transmit holding register */
    uint16_t		tsr; 				/* transmit shift register	*/

	uint16_t		fcr_vmstate;		/* dont't write directly this value */
	uint16_t		divider;
	uint64_t		clock;
	uint64_t		char_transmit_time;	/* time to transmit a char in ticks	*/

	int				it_shift;
    int				thr_ipending;
    int				last_break_enable;
    int				tsr_retry;
    int				poll_msl;
	int				timeout_ipending;	/* timeout interrupt pending state */

	QemuTimer*		fifo_timeout_timer; /* timer for read fifo timeout */
    QEMUTimer*		transmit_timer;		/* timer for transmit */
    QEMUTimer*		modem_status_poll;	/* timer for update modem status */

	CharDriverState	*chr;
	qemu_irq		irq;
}em1uart_state;


static void em1uart_receive(void *opaque, const uint8_t *buf, int size);

static void fifo_clear(em1uart_state *s, int fifo)
{
    SerialFIFO *f = (fifo) ? &s->recv_fifo : &s->xmit_fifo;
    memset(f->data, 0, s->fifo_size);
    f->count = 0;
    f->head = 0;
    f->tail = 0;
}

static void em1uart_reset(void* opaque)
{
	em1uart_state* s = (em1uart_state*)opaque;

	int i;
	for (i = 0; i < 21; i++)
	{
		if (9 == i || 10 == i) continue;
		s->regs[i] = 0;
	}
	s->regs[2]  = 0x0001;	/* IIR������   */
	s->regs[6]  = 0x0060;	/* LSR������   */
	s->regs[17] = 0x0002;	/* ICCR1������ */

	/* Default to 9600 baud, 1 start bit, 8 data bits, 1 stop bit, no parity. */
    s->divider = 0x05D5;
    s->tsr_retry = 0;
    s->char_transmit_time = (get_ticks_per_sec() / 9600) * 10;
    s->poll_msl = 0;

	s->fifo_size = 1;
    fifo_clear(s,RECV_FIFO);
    fifo_clear(s,XMIT_FIFO);

    s->thr_ipending = 0;
    s->last_break_enable = 0;
    qemu_irq_lower(s->irq);
}

/* ���荞�ݗv��/���� */
static void serial_update_irq(em1uart_state *s)
{
    uint8_t tmp_iir = IIR_NO_INT;

    if ((s->regs[1] & IER_RLSI) && (s->regs[6] & LSR_INT_ANY)) {
        tmp_iir = IIR_RLSI;	/* Receiver line status interrupt */
    } else if ( ((s->regs[11] & HCR0_RCV_TMO_DIS) || (s->regs[1] & IER_RDI))
    		    && s->timeout_ipending ) {
    	/* HCR0[4]��1�̂Ƃ��AIER�̐ݒ�Ɋ֌W�Ȃ�Timeout�����荞�ݗv���ɂȂ� */
        /* Note that(s->regs[1] & IER_RDI) can mask this interrupt,
         * this is not in the specification but is observed on existing
         * hardware.  */
        tmp_iir = IIR_CTI;
    } else if ((s->regs[1] & IER_RDI) && (s->regs[6] & LSR_DR) &&
               (!FIFO_ENABLE(s) || s->recv_fifo.count >= s->recv_fifo.itl)) {
        tmp_iir = IIR_RDI;
    } else if ((s->regs[1] & IER_THRI) && s->thr_ipending) {
        tmp_iir = IIR_THRI;
    } else if ((s->regs[1] & IER_MSI) && (s->regs[7] & MSR_ANY_DELTA)) {
        tmp_iir = IIR_MSI;
    }
	UART_P_DBG("IER:%x IIR:%x tmp_iir:%x\n", s->regs[1], s->regs[2], tmp_iir);

	s->regs[2] = tmp_iir | (s->regs[2] & 0xF0);
	qemu_set_irq(s->irq, tmp_iir != IIR_NO_INT);
}

static void serial_update_parameters(em1uart_state *s)
{
    int frame_size;
    QEMUSerialSetParams ssp;

    if (s->divider == 0 || s->clock < s->divider || !s->chr)
	{
		UART_P_DBG("ERROR! divider:%x clock:%x chr:%x\n", s->divider, s->clock, s->chr);
		return;
	}

    /* Start bit. */
    frame_size = 1;

	if (s->regs[4] & LCR_PARITY_ENABLE)
	{
        /* Parity bit. */
        frame_size++;
		if (s->regs[4] & LCR_PARITY_STICK)
		{	/* ? �Œ�Parity�`�F�b�N */
	        if (s->regs[4] & LCR_PARITY_EVEN)
	            ssp.parity = 'L';				/* Low  */
	        else
	            ssp.parity = 'H';				/* High */
		}
		else
		{
	        if (s->regs[4] & LCR_PARITY_EVEN)
	            ssp.parity = 'E';				/* ���� */
	        else
	            ssp.parity = 'O';				/* � */
		}
    }
	else
	{
    	ssp.parity = 'N';
    }
    if (s->regs[4] & LCR_NUM_STOP2)
        ssp.stop_bits = 2;
    else
        ssp.stop_bits = 1;

    ssp.data_bits = (s->regs[4] & 0x03) + 5;
    frame_size += ssp.data_bits + ssp.stop_bits;
	ssp.speed = s->clock / s->divider;
    s->char_transmit_time =  (get_ticks_per_sec() / ssp.speed) * frame_size;
    qemu_chr_ioctl(s->chr, CHR_IOCTL_SERIAL_SET_PARAMS, &ssp);

	UART_P_DBG("clock%d, div:%d, ticks:%d\n", s->clock, s->divider, get_ticks_per_sec());
	UART_P_DBG("speed=%d parity=%c data=%d stop=%d\n", 
			   ssp.speed, ssp.parity, ssp.data_bits, ssp.stop_bits);
}

static uint8_t fifo_get(em1uart_state *s, int fifo)
{
    SerialFIFO *f = (fifo) ? &s->recv_fifo : &s->xmit_fifo;
    uint8_t c;

    if (f->count == 0)
        return 0;

    c = f->data[f->tail++];
    if (f->tail == s->fifo_size)
        f->tail = 0;
    f->count--;

    return c;
}

/* Modem Status Line ���X�V����BBackend���{����Serial Port�����̂Ƃ��ɍs���܂� */
static void serial_update_msl(em1uart_state *s)
{
    uint8_t omsr;
    int flags;

    if (!s->chr ||
    	qemu_chr_ioctl(s->chr, CHR_IOCTL_SERIAL_GET_TIOCM, &flags) == -ENOTSUP) {
		UART_P_DBG("no real serial. ioctl:%x\n", s->chr);
    	s->poll_msl = -1;
        return;
    }

	qemu_del_timer(s->modem_status_poll);

    omsr = s->regs[7];
	s->regs[7] = (flags & CHR_TIOCM_CTS) ? s->regs[7] | MSR_CTS : s->regs[7] & ~MSR_CTS;
    s->regs[7] = (flags & CHR_TIOCM_DSR) ? s->regs[7] | MSR_DSR : s->regs[7] & ~MSR_DSR;
    s->regs[7] = (flags & CHR_TIOCM_CAR) ? s->regs[7] | MSR_DCD : s->regs[7] & ~MSR_DCD;
    s->regs[7] = (flags & CHR_TIOCM_RI)  ? s->regs[7] | MSR_RI  : s->regs[7] & ~MSR_RI;
	UART_P_DBG("MSR:%x OldMSR:%x Flags:%x\n", s->regs[7], omsr, flags);

    if (s->regs[7] != omsr) {
         /* Set delta bits */
         s->regs[7] = s->regs[7] | ((s->regs[7] >> 4) ^ (omsr >> 4));
         /* MSR_TERI only if change was from 1 -> 0 */
         if ((s->regs[7] & MSR_TERI) && !(omsr & MSR_RI))
             s->regs[7] &= ~MSR_TERI;
         serial_update_irq(s);
    }

    /* The real 16550A apparently has a 250ns response latency to line status changes.
       We'll be lazy and poll only every 10ms, and only poll it at all if MSI interrupts are turned on */
    if (s->poll_msl)
        qemu_mod_timer(s->modem_status_poll, qemu_get_clock(vm_clock) + get_ticks_per_sec() / 100);
}

static uint32_t serial_ioport_read(void *opaque, uint32_t addr)
{
	uint32_t		ret = 0;
	em1uart_state*	s   = (em1uart_state*)opaque;

    addr &= 7;
	UART_P_DBG("offset:%d\n", addr);
    switch(addr)
	{
	case 0:
        if (FIFO_ENABLE(s))
		{
            ret = fifo_get(s, RECV_FIFO);
			if (s->recv_fifo.count == 0) {
                s->regs[6] &= ~(LSR_DR);
			}
			else {
				/* Host����̍Ō��read��4char�̓]���^�C�������O�ɂ��鎞�ATimeout(3.2.2) */
                qemu_mod_timer(s->fifo_timeout_timer, qemu_get_clock (vm_clock) + s->char_transmit_time * 4);
			}
			/* Timeout���荞�݉���(3.2.3) */
            s->timeout_ipending = 0;
        }
		else
		{
            ret = s->rbr;
            s->regs[6] &= ~(LSR_DR);
        }
        serial_update_irq(s);

        if (!(s->regs[5] & MCR_LOOP) && s->chr) {
            /* in loopback mode, don't receive any data */
            qemu_chr_accept_input(s->chr);
        }
		break;

	case 2:									/* IIR */
        ret = s->regs[2];

		/* IIR�����[�h����ƁATHRI���荞�݂�����(�\3-2) */
		s->thr_ipending = 0;
        serial_update_irq(s);
        break;

	case 6:									/* LSR */
        ret = s->regs[6];

		/* Receiver line staus ���荞�݉��� */
		s->regs[6] &= ~(LSR_RFIFO_ERR | 0x001E);
		serial_update_irq(s);
        break;

	case 7:									/* MSR */
        if (s->regs[5] & MCR_LOOP) {
            /* in loopback, the modem output pins are connected to the
               inputs */
            ret = (s->regs[5] & 0x0c) << 4;
            ret |= (s->regs[5] & 0x02) << 3;
            ret |= (s->regs[5] & 0x01) << 5;
        } else {
            if (s->poll_msl >= 0)
                serial_update_msl(s);
            ret = s->regs[7];
            /* Clear delta bits & msr���荞�� after read, if they were set */
            if (s->regs[7] & MSR_ANY_DELTA) {
                s->regs[7] &= 0xF0;
                serial_update_irq(s);
            }
        }
        break;

	case 12:
		ret = s->regs[addr];
		s->regs[12] &= ~HCR2_RFIFO_EMPTY;
		break;
	case 13:
		ret = s->regs[addr];
		s->regs[13] &= ~HCR3_TFIFO_FULL;
		break;

	case 1:case 3:case 4:case 5:case 8:case 9:case 10:
	case 11:case 16:case 17:case 18:case 19:case 20:
		ret = s->regs[addr];
		break;
	case 14:case 15:								/* Reserved  */
	default:
		hw_error("serial_ioport_read: Bad offset %x\n", (int)addr);
	}

	UART_P_DBG("ret:0x%x\n", ret);
	return ret;
}

static void serial_xmit(void *opaque)
{
    em1uart_state *s = opaque;
    uint64_t new_xmit_ts = qemu_get_clock(vm_clock);

    if (s->tsr_retry <= 0) {	/* tsr is empty. get 1char to tsr */
        if (FIFO_ENABLE(s)) {
            s->tsr = fifo_get(s,XMIT_FIFO);
            if (!s->xmit_fifo.count)
                s->regs[6] |= LSR_THRE;
        } else {
            s->tsr = s->thr;
            s->regs[6] |= LSR_THRE;
        }
    }

    if (s->regs[5] & MCR_LOOP) {
        /* in loopback mode, say that we just received a char */
        em1uart_receive(s, (uint8_t*)&s->tsr, 1);
    } else {
    	int bok;
    	if (s->regs[11] & HCR0_ACCESS_2BYTE) {
    		bok = qemu_chr_write(s->chr, (uint8_t*)&s->tsr, 2);
    		s->tsr = (s->tsr >> 8) | (s->tsr << 8);
    	} else {
    		bok = qemu_chr_write(s->chr, (uint8_t*)&s->tsr, 1);
    	}

    	if (bok != 1) {
	        if ((s->tsr_retry > 0) && (s->tsr_retry <= MAX_XMIT_RETRY)) {
	            s->tsr_retry++;
	            qemu_mod_timer(s->transmit_timer,  new_xmit_ts + s->char_transmit_time);
	            return;
	        } else if (s->poll_msl < 0) {
	            /* If we exceed MAX_XMIT_RETRY and the backend is not a real serial port, then
	            drop any further failed writes instantly, until we get one that goes through.
	            This is to prevent guests that log to unconnected pipes or pty's from stalling. */
	            s->tsr_retry = -1;
	        }
    	}
	    else {
	        s->tsr_retry = 0;
	    }
    }

    if (s->regs[6] & LSR_THRE) {
        s->regs[6] |= LSR_TEMT;
        s->thr_ipending = 1;
        serial_update_irq(s);
    }
	else {		/* fifo is not empty. transmit again after 1char time */
        qemu_mod_timer(s->transmit_timer, qemu_get_clock(vm_clock) + s->char_transmit_time);
	}
}

static int fifo_put(em1uart_state *s, int fifo, uint8_t chr)
{
    SerialFIFO *f = (fifo) ? &s->recv_fifo : &s->xmit_fifo;

    f->data[f->head++] = chr;

    if (f->head == s->fifo_size)
        f->head = 0;
    f->count++;

    return 1;
}

static void serial_ioport_write(void *opaque, uint32_t addr, uint32_t val)
{
    em1uart_state *s = (em1uart_state *)opaque;

	UART_P_DBG("offset:%d val:0x%x\n", addr, val);
    addr &= 7;
	switch (addr)
	{
	case 0:
        s->thr = val;
        if (FIFO_ENABLE(s)) {
			fifo_put(s, XMIT_FIFO, s->thr);
			s->regs[6] &= ~LSR_TEMT;
        }
		s->regs[6] &= ~LSR_THRE;
        s->thr_ipending = 0;
        serial_update_irq(s);
        serial_xmit(s);
        break;

	case 1:
		s->regs[1] = val & 0x0f;
		/* If the backend device is a real serial port, turn polling of the modem
		   status lines on physical port on or off depending on IER_MSI state */
		if (s->poll_msl >= 0) {
		    if (s->regs[1] & IER_MSI) {
		         s->poll_msl = 1;
		         serial_update_msl(s);
		    } else {
		         qemu_del_timer(s->modem_status_poll);
		         s->poll_msl = 0;
		    }
		}
		if (s->regs[6] & LSR_THRE) {
		    s->thr_ipending = 1;
		    serial_update_irq(s);
		}
        break;

	case 2:
		break;

	case 3:
        val = val & 0xFF;
        if (s->regs[3] == val)
            break;

        /* Did the enable/disable flag change? If so, make sure FIFOs get flushed */
        if ((val ^ s->regs[3]) & FCR_FIFO)
            val |= FCR_XFIFO_RESET | FCR_RFIFO_RESET;
        /* Read FIFO clear */
        if (val & FCR_RFIFO_RESET) {
            qemu_del_timer(s->fifo_timeout_timer);
            s->timeout_ipending = 0;
            fifo_clear(s,RECV_FIFO);
        }
        /* Write FIFO clear */
        if (val & FCR_XFIFO_RESET) {
            fifo_clear(s,XMIT_FIFO);
        }

        if (val & FCR_FIFO)
		{
            s->regs[2] |= IIR_FE;
            /* Set RECV_FIFO trigger Level */
        	if (val & FCR_FIFO64)
        	{
				s->fifo_size = 64;
				s->regs[2] |= val & FCR_FIFO64;
	            switch (val & 0xC0)
        		{
	            case FCR_ITL_1:
	                s->recv_fifo.itl = 1;
	                break;
	            case FCR_ITL_2:
	                s->recv_fifo.itl = 16;
	                break;
	            case FCR_ITL_3:
	                s->recv_fifo.itl = 32;
	                break;
	            case FCR_ITL_4:
	                s->recv_fifo.itl = 56;
	                break;
	            }
            }
        	else
        	{
				s->fifo_size = 16;
	            switch (val & 0xC0)
        		{
	            case FCR_ITL_1:
	                s->recv_fifo.itl = 1;
	                break;
	            case FCR_ITL_2:
	                s->recv_fifo.itl = 4;
	                break;
	            case FCR_ITL_3:
	                s->recv_fifo.itl = 8;
	                break;
	            case FCR_ITL_4:
	                s->recv_fifo.itl = 14;
	                break;
	            }
        	}
        }
		else
		{
            s->regs[2] &= ~IIR_FE;
			s->fifo_size = 1;
		}

        /* FIFO Reset Bit �� 0 �ɃN���A���� */
        s->regs[3] = val & 0xE9;

		serial_update_irq(s);
		break;

	case 4:										/* LCR */
	{
        s->regs[4] = val;

		serial_update_parameters(s);

		/* Break�����A�Ώ�Serial Dev�ɒʒm���� */
        int break_enable = (val >> 6) & 1;
        if (break_enable != s->last_break_enable) {
            s->last_break_enable = break_enable;
        	if (s->chr)
	            qemu_chr_ioctl(s->chr, CHR_IOCTL_SERIAL_SET_BREAK, &break_enable);
        }
    }break;

	case 5:										/* MCR */
	{
	    int flags;
	    int old_mcr = s->regs[5];
	    s->regs[5] = val & 0x1f;
	    if (val & MCR_LOOP)
	        break;

		if (s->poll_msl >= 0 && old_mcr != s->regs[5]) {
	        qemu_chr_ioctl(s->chr, CHR_IOCTL_SERIAL_GET_TIOCM, &flags);

	        flags &= ~(CHR_TIOCM_RTS | CHR_TIOCM_DTR);

	        if (val & MCR_RTS)
	            flags |= CHR_TIOCM_RTS;
	        if (val & MCR_DTR)
	            flags |= CHR_TIOCM_DTR;

	        qemu_chr_ioctl(s->chr,CHR_IOCTL_SERIAL_SET_TIOCM, &flags);
	        /* Update the modem status after a one-character-send wait-time, since there may be a response
	           from the device/computer at the other end of the serial line */
	        qemu_mod_timer(s->modem_status_poll, qemu_get_clock(vm_clock) + s->char_transmit_time);
	    }
	}break;

	case 9:
		if (s->regs[4] & LCR_DLAB)
		{
			s->regs[addr] = val;
            s->divider = (s->divider & 0xff00) | val;
            serial_update_parameters(s);
		}
		break;

	case 10:
		if (s->regs[4] & LCR_DLAB)
		{
			s->regs[addr] = val;
            s->divider = (s->divider & 0x00ff) | (val << 8);
            serial_update_parameters(s);
		}
		break;

	case 11:
		s->regs[addr] = val;
		if (s->regs[addr] & HCR0_SW_RESET)
			em1uart_reset(s);
		break;

	case 8:case 16:case 17:case 18:case 19:case 20:
		s->regs[addr] = val;
		break;

	case 6:case 7:case 12:case 13:			/* Read Only */
	case 14:case 15:						/* Reserved  */
	default:
		hw_error("serial_ioport_write: Bad offset %x\n", (int)addr);
	}
}

static int em1uart_can_receive(void *opaque)
{
	int ret = 0;
	int full = 1;
	em1uart_state *s = (em1uart_state *)opaque;

    if (FIFO_ENABLE(s))
	{
		UART_P_DBG("FCR:%x count:%d itl:%d size:%d\n", s->regs[3], s->recv_fifo.count, s->recv_fifo.itl, s->fifo_size);
		if (s->recv_fifo.count < s->fifo_size) {
			ret = (s->recv_fifo.count <= s->recv_fifo.itl) ? s->recv_fifo.itl - s->recv_fifo.count : 1;
			full = 0;
		}
    }
	else
	{
		ret = !(s->regs[6] & LSR_DR);
    }

	if (full) {
		/* ��MBuffer Overrun���o */
		s->regs[6] |= LSR_OE;
		serial_update_irq(s);
	}
	return ret;
}

static void em1uart_receive(void *opaque, const uint8_t *buf, int size)
{
    em1uart_state* s = opaque;
    if (FIFO_ENABLE(s))
	{
        int i;
        for (i = 0; i < size; i++) {
			UART_P_DBG("FCR:%x char:%c\n", s->regs[3], buf[i]);
            fifo_put(s, RECV_FIFO, buf[i]);
        }
		s->regs[6] |= LSR_DR;				/* Receiver data ready		*/

		/* Timeout���荞��Timer�N��
		 * ��M�����Ō�̃f�[�^��4char�̓]�����Ԃ����O�ɂ���Ƃ��ATimeout(3.2.2)
         * call the timeout receive callback in 4 char transmit time				*/
        qemu_mod_timer(s->fifo_timeout_timer, 
        			   qemu_get_clock(vm_clock) + s->char_transmit_time * 4);
    }
	else
	{
        s->rbr = buf[0];
		s->regs[6] |= LSR_DR;				/* Receiver data ready */
    }
    serial_update_irq(s);
}

static void serial_receive_break(em1uart_state *s)
{
    /* When the LSR_DR is set a null byte is pushed into the fifo
	   Break���荞�ݎ�M���AALL0�̃f�[�^����M�������܂� 3.2.7    */
	if (FIFO_ENABLE(s))
	    fifo_put(s, RECV_FIFO, '\0');
	else
	    s->rbr = 0;

	s->regs[6] |= LSR_BI | LSR_DR;
    serial_update_irq(s);
}

static void em1uart_event(void *opaque, int event)
{
    em1uart_state *s = opaque;

	UART_P_DBG("serial: event %x\n", event);
    if (event == CHR_EVENT_BREAK)
        serial_receive_break(s);
}


/*---------------------- Memory mapped interface ----------------------------*/
static uint32_t serial_mm_readb(void *opaque, target_phys_addr_t addr)
{
    em1uart_state *s = opaque;

    return serial_ioport_read(s, addr >> s->it_shift) & 0xFF;
}

static void serial_mm_writeb(void *opaque, target_phys_addr_t addr,
                             uint32_t value)
{
    em1uart_state *s = opaque;

    serial_ioport_write(s, addr >> s->it_shift, value & 0xFF);
}

static uint32_t serial_mm_readw(void *opaque, target_phys_addr_t addr)
{
    em1uart_state *s = opaque;
    uint32_t val;

    val = serial_ioport_read(s, addr >> s->it_shift) & 0xFFFF;
#ifdef TARGET_WORDS_BIGENDIAN
    val = bswap16(val);
#endif
    return val;
}

static void serial_mm_writew(void *opaque, target_phys_addr_t addr,
                             uint32_t value)
{
    em1uart_state *s = opaque;
#ifdef TARGET_WORDS_BIGENDIAN
    value = bswap16(value);
#endif
    serial_ioport_write(s, addr >> s->it_shift, value & 0xFFFF);
}

static uint32_t serial_mm_readl(void *opaque, target_phys_addr_t addr)
{
    em1uart_state *s = opaque;
    uint32_t val;

    val = serial_ioport_read(s, addr >> s->it_shift);
#ifdef TARGET_WORDS_BIGENDIAN
    val = bswap32(val);
#endif
    return val;
}

static void serial_mm_writel(void *opaque, target_phys_addr_t addr,
                             uint32_t value)
{
    em1uart_state *s = opaque;
#ifdef TARGET_WORDS_BIGENDIAN
    value = bswap32(value);
#endif
    serial_ioport_write(s, addr >> s->it_shift, value);
}

static CPUReadMemoryFunc * const em1uart_readfn[] = {
	serial_mm_readb,
	serial_mm_readw,
	serial_mm_readl
};

static CPUWriteMemoryFunc * const em1uart_writefn[] = {
	serial_mm_writeb,
	serial_mm_writew,
	serial_mm_writel
};
/*---------------------- Memory mapped interface End ------------------------*/

/* Callback while data in recv_fifo has not been read 
   for 4 char transmit times                                                 */
static void fifo_timeout_int (void *opaque)
{
    em1uart_state *s = opaque;

    if (s->recv_fifo.count)	/* FIFO���f�[�^���Ȃ���΁ATimeout���������Ȃ�(3.2.2) */
	{
        s->timeout_ipending = 1;
        serial_update_irq(s);
    }
}

static void serial_pre_save(void *opaque)
{
    em1uart_state *s = opaque;
    s->fcr_vmstate = s->regs[3];
}

static int serial_post_load(void *opaque, int version_id)
{
    em1uart_state *s = opaque;

    if (version_id < 3) {
        s->fcr_vmstate = 0;
    }
    /* Initialize fcr via setter to perform essential side-effects */
    serial_ioport_write(s, 0x03, s->fcr_vmstate);
    return 0;
}

static const VMStateDescription vmstate_serial = {
    .name = "em1uart",
    .version_id = 3,
    .minimum_version_id = 2,
    .pre_save = serial_pre_save,
    .post_load = serial_post_load,
    .fields      = (VMStateField []) {
        VMSTATE_UINT16_V(divider, em1uart_state, 2),
        VMSTATE_UINT16(regs[0],  em1uart_state),
        VMSTATE_UINT16(regs[1],  em1uart_state),
        VMSTATE_UINT16(regs[2],  em1uart_state),
        VMSTATE_UINT16(regs[3],  em1uart_state),
        VMSTATE_UINT16(regs[4],  em1uart_state),
        VMSTATE_UINT16(regs[5],  em1uart_state),
        VMSTATE_UINT16(regs[6],  em1uart_state),
        VMSTATE_UINT16(regs[7],  em1uart_state),
        VMSTATE_UINT16(regs[8],  em1uart_state),
        VMSTATE_UINT16(regs[9],  em1uart_state),
        VMSTATE_UINT16(regs[10], em1uart_state),
        VMSTATE_UINT16(regs[11], em1uart_state),
        VMSTATE_UINT16(regs[12], em1uart_state),
        VMSTATE_UINT16(regs[13], em1uart_state),
        VMSTATE_UINT16(regs[14], em1uart_state),
        VMSTATE_UINT16(regs[15], em1uart_state),
        VMSTATE_UINT16(regs[16], em1uart_state),
        VMSTATE_UINT16(regs[17], em1uart_state),
        VMSTATE_UINT16(regs[18], em1uart_state),
        VMSTATE_UINT16(regs[19], em1uart_state),
        VMSTATE_UINT16(regs[20], em1uart_state),
        VMSTATE_UINT16_V(fcr_vmstate, em1uart_state, 3),
        VMSTATE_END_OF_LIST()
    }
};

static void init_core(em1uart_state* s)
{
	s->it_shift = 2;

	s->regs[9] = 0;
	s->regs[10] = 0;
	em1uart_reset(s);
	
    s->modem_status_poll = qemu_new_timer(vm_clock, (QEMUTimerCB *) serial_update_msl, s);
    s->fifo_timeout_timer = qemu_new_timer(vm_clock, (QEMUTimerCB *) fifo_timeout_int, s);
    s->transmit_timer = qemu_new_timer(vm_clock, (QEMUTimerCB *) serial_xmit, s);

	if (s->chr)
	{
		qemu_chr_add_handlers(s->chr, em1uart_can_receive, em1uart_receive,
                              em1uart_event, s);
    }    serial_update_msl(s);
	qemu_register_reset(em1uart_reset, s);
	vmstate_register(-1, &vmstate_serial, s);
}

static int em1uart_init(SysBusDevice *dev)
{
    int iomemtype;
    em1uart_state *s = FROM_SYSBUS(em1uart_state, dev);

    iomemtype = cpu_register_io_memory(em1uart_readfn, em1uart_writefn, s);
    sysbus_init_mmio(dev, 0x10000, iomemtype);
    sysbus_init_irq(dev, &s->irq);
	s->chr = qdev_init_chardev(&dev->qdev);

	s->clock = 14336000;			/* 229376000 / 16 */
	init_core(s);
    return 0;
}

extern em1uart_state* em1uart_create(target_phys_addr_t base, CharDriverState *chr, uint64_t clock, qemu_irq irq)
{
    em1uart_state* s;
    int s_io_memory;

    s = qemu_mallocz(sizeof(em1uart_state));

	s->irq = irq;
	s->clock = clock / 16;
	s->chr = chr;

	s_io_memory = cpu_register_io_memory(em1uart_readfn,
                                         em1uart_writefn, s);
    cpu_register_physical_memory(base, 21 << 2, s_io_memory);

	init_core(s);
	return s;
}

static void em1uart_register_devices(void)
{
    sysbus_register_dev("em1uart", sizeof(em1uart_state), em1uart_init);
}

device_init(em1uart_register_devices);
