#include "sysbus.h"
#include "console.h"
#include "pixel_ops.h"
#include "framebuffer.h"

/*******************************************************************************/
#define LCD_CONTROL				0x0000
#define LCD_QOS					0x0004
#define LCD_DATAREQ				0x0008
#define LCD_LCDOUT				0x0010
#define LCD_BUSSEL				0x0014
#define LCD_STATUS				0x0018
#define LCD_BACKCOLOR			0x001C
#define LCD_AREAADR				0x0020
#define LCD_HOFFSET				0x0024
#define LCD_IFORMAT				0x0028
#define LCD_HTOTAL				0x0030
#define LCD_HAREA				0x0034
#define LCD_HEDGE1				0x0038
#define LCD_HEDGE2				0x003C
#define LCD_VTOTAL				0x0040
#define LCD_VAREA				0x0044
#define LCD_VEDGE1				0x0048
#define LCD_VEDGE2				0x004C

#define LCD_INTSTATUS			0x0060
#define LCD_INTRAWSTATUS		0x0064
#define LCD_INTENSET			0x0068
#define LCD_INTENCLR			0x006C
#define LCD_INTFFCLR			0x0070
#define LCD_FRAMECOUNT			0x0074

/*******************************************************************************/
typedef struct __lcd_state__
{
	SysBusDevice	busdev;
	DisplayState*	dstate;
	
	int				wbflag;					// WB req flag
	int				invalidate;
	
	
	////////////////////////////////////////////////////////////////////////////
	uint32_t		lcdout;
	uint32_t		lcdbussel;
	uint32_t		lcdstatus;
	uint32_t		lcdbackcolor;
	
	uint32_t		lcdareaadr;
	uint32_t		lcdhoffset;
	uint32_t		lcdiformat;
	////////////////////////////////////////////////////////////////////////////
/*
					LCD							
	|<------------HTOTAL----------->|			
	+----+--------------------------+<----------
	|    |                          |			|
	|    |<--------- HAREA -------->|			|
	+----+--------------------------+<--		|
	|    | / / / / / / / / / / / /  |	|		|
	|    | / / / / / / / / / / / /  |	|		| VTOTAL
	|    | / / / / / / / / / / / /  |	|		|
	|    | / / / / / / / / / / / /  |	|VAREA	|
	|    | / / / / / / / / / / / /  |	|		|
	|    | / / / / / / / / / / / /  |	|		|
	+----+--------------------------+<----------
*/
	uint32_t		lcdhtotal;
	uint32_t		lcdharea;
	uint32_t		lcdvtotal;
	uint32_t		lcdvarea;
	////////////////////////////////////////////////////////////////////////////
	uint32_t		lcdintstatus;
	uint32_t		lcdintrawstatus;
	
	/*
	uint32_t		lcdintenset;
	uint32_t		lcdintenclr;
	*/
	uint32_t		lcdintenable;
	/*
	uint32_t		lcdintffclr;
	*/
	uint32_t		lcdintresult;
	uint32_t		lcdframecount;
	
	qemu_irq		irq;					// IRQ...
}LCD_STATE, *PLCD_STATE;

// Interrrupt 
#define WBTRACE		0x00000010
#define FRMCOUNT	0x00000008
#define LCDSTOP		0x00000004
#define UNDERRUN	0x00000002
#define LCDVS		0x00000001

/********************************************************************************/
#define DEPTH	8
#include "tef_em1d_lcd_template.h"
#define DEPTH	15
#include "tef_em1d_lcd_template.h"
#define DEPTH	16
#include "tef_em1d_lcd_template.h"
#define DEPTH	24
#include "tef_em1d_lcd_template.h"
#define DEPTH	32
#include "tef_em1d_lcd_template.h"

static drawfn drawline_table[2][5] = 
{
	{
		draw_line16_8,
		draw_line16_15,
		draw_line16_16,
		draw_line16_24,
		draw_line16_32,
	},
	{
		draw_line18_8,
		draw_line18_15,
		draw_line18_16,
		draw_line18_24,
		draw_line18_32,
	}
};

static void draw_line(void *opaque, int row, int width, int pitch, uint8_t r, uint8_t g, uint8_t b)
{
	int			i, outbpp;
	uint8_t*	lcdframe = NULL;
	LCD_STATE*	lcdstate = (LCD_STATE*)opaque;
	
	// start position and bpp
	lcdframe	= ds_get_data(lcdstate->dstate);
	lcdframe	+= (row * width + pitch);
	outbpp		= ds_get_bytes_per_pixel(lcdstate->dstate);
	
	for (i = 0; i < width - pitch; i++) {
		switch(outbpp) {
		case 8:
			*(uint8_t *)lcdframe		= rgb_to_pixel8(r, g, b);
			lcdframe	++;
			break;
		case 15:
			*(uint16_t *)lcdframe 		= rgb_to_pixel15(r, g, b);
			lcdframe	+= 2;
			break;
		case 16:
			*(uint16_t *)lcdframe 		= rgb_to_pixel15(r, g, b);
			lcdframe	+= 2;
			break;
		case 24:
			*(uint16_t *)lcdframe		= rgb_to_pixel24(r, g, b); 
			*(uint8_t *)(lcdframe + 2)	= rgb_to_pixel24(r, g, b) >> 16;
			lcdframe	+= 3;
			break;
		case 32:
			*(uint32_t *)lcdframe 		= rgb_to_pixel32(r, g, b);
			lcdframe	+= 4;
			break;
		}
	}
}

/********************************************************************************/
static void em1d_update_display(void *opaque)
{
	int			inbpp, outbpp, idx, idy;
	int			first_col, first_row, last_row;
	int			inline_step, outline_step;
	
	drawfn		drawline;
	LCD_STATE*	lcdstate = (LCD_STATE*)opaque;
	
	////////////////////////////////////////////////////////////////////////////
	// check device whether is enabled
	if (!lcdstate->lcdout) 								// display nothing
	{
		// raise interrupt and update int register
		if (lcdstate->lcdintenable & LCDSTOP) {
			lcdstate->lcdintstatus	|= LCDSTOP;
			qemu_irq_raise(lcdstate->irq);
		}
		//lcdstate->lcdintrawstatus	|= LCDSTOP;
		return ;
	} else {
		lcdstate->lcdintstatus		&= ~LCDSTOP;
		//lcdstate->lcdintrawstatus	&= ~LCDSTOP;
	}
	
	if( !ds_get_bits_per_pixel(lcdstate->dstate) ||						// there is no lcd hardware 
		0 == lcdstate->lcdharea || 0 == lcdstate->lcdvarea ||			// not set display area yet
		0 == lcdstate->lcdhtotal || 0 == lcdstate->lcdvtotal) 			// not set max lcd size
	{
		return ;
	}
	
	// check console size and adjust it 
	if ((lcdstate->lcdharea != ds_get_width(lcdstate->dstate)) ||
		(lcdstate->lcdvarea != ds_get_height(lcdstate->dstate))) 
	{
		qemu_console_resize(lcdstate->dstate, lcdstate->lcdharea, lcdstate->lcdvarea);
		lcdstate->invalidate = 1;
	}
	
	// caculate start-position 
	first_col = first_row = 0;
	
	// check bus select mode
	if (1 == lcdstate->lcdbussel) {								// MEMC-LCD
		inbpp		= (lcdstate->lcdiformat)?(16):(18);			// RGB565: 16bits	RGB666: 18bits
		outbpp		= ds_get_bits_per_pixel(lcdstate->dstate);	// 8 15 16 24 32
		
		// choose drawline function
		idx			= (16 == inbpp)?(0):(1);
		idy			= (outbpp / 8);
		drawline	= drawline_table[idx][idy];
		
		// caculate source frame step and lcd frame-buffer step
		inline_step	= lcdstate->lcdhoffset;
		outline_step = lcdstate->lcdharea * ds_get_bytes_per_pixel(lcdstate->dstate);
		
		// draw each line according to conditions
		framebuffer_update_display( lcdstate->dstate,
									lcdstate->lcdareaadr,
									lcdstate->lcdharea, lcdstate->lcdvarea,		// display area[width,height]
									inline_step, outline_step, 0, lcdstate->invalidate,
									drawline, lcdstate, &first_row, &last_row);
		// update the display area
		if (first_row >= 0) {
			dpy_update(lcdstate->dstate, first_col, first_row, lcdstate->lcdharea, last_row - first_row + 1);
		}
	} else if (4 == lcdstate->lcdbussel) {						// Black Back
		for (idx = first_row; idx < lcdstate->lcdvarea; idx++) {
			draw_line(lcdstate->dstate, idx, lcdstate->lcdharea, first_col, 0xFF, 0xFF, 0xFF);
		}
	} else if (5 == lcdstate->lcdbussel) {						// Fixed Color[RGB]
		int r, g, b;
		r	= (lcdstate->lcdbackcolor >> 0x10) & 0x3F;
		g	= (lcdstate->lcdbackcolor >> 0x08) & 0x3F;
		b	= (lcdstate->lcdbackcolor >> 0x00) & 0x3F;
		for (idx = first_row; idx < lcdstate->lcdvarea; idx++) {
			draw_line(lcdstate->dstate, idx, lcdstate->lcdharea, first_col, r, g, b);
		}
	}
	lcdstate->invalidate = 0;
	
	// raise lcdvs interrupt
	if (lcdstate->lcdintenable & LCDVS) {
		lcdstate->lcdintstatus		|= LCDVS;
		qemu_irq_raise(lcdstate->irq);
	}
	//lcdstate->lcdintrawstatus		|= LCDVS;
}

static void em1d_invalidate_display(void *opaque)
{
	LCD_STATE*	lcdstate;
	
	lcdstate = (LCD_STATE*)opaque;
	lcdstate->invalidate = 1;
	
	// check console size and adjust it 
	if ((lcdstate->lcdharea != ds_get_width(lcdstate->dstate)) ||
		(lcdstate->lcdvarea != ds_get_height(lcdstate->dstate))) 
	{
		qemu_console_resize(lcdstate->dstate, lcdstate->lcdharea, lcdstate->lcdvarea);
	}
}

static uint32_t em1d_lcdc_read(void *opaque, target_phys_addr_t offset)
{
	LCD_STATE*			lcdstate;
	//printf("%s:%d[0x%04x]\n", __FUNCTION__, __LINE__, offset);
	lcdstate = (LCD_STATE*)opaque;
	switch(offset)
	{
	case LCD_LCDOUT:
		return lcdstate->lcdout;
	case LCD_BUSSEL:
		return lcdstate->lcdbussel;
	case LCD_STATUS:
		return lcdstate->lcdstatus;
	case LCD_BACKCOLOR:
		return lcdstate->lcdbackcolor;
	case LCD_AREAADR:
		return lcdstate->lcdareaadr;
	case LCD_HOFFSET:
		return lcdstate->lcdhoffset;
	case LCD_IFORMAT:
		return lcdstate->lcdiformat;
	case LCD_HTOTAL:
		return lcdstate->lcdhtotal;
	case LCD_HAREA:
		return lcdstate->lcdharea;
	case LCD_VTOTAL:
		return lcdstate->lcdvtotal;
	case LCD_VAREA:
		return lcdstate->lcdvarea;
		
	case LCD_INTSTATUS:
		return (lcdstate->lcdintstatus		& 0xFFFFFFFF);
	case LCD_INTRAWSTATUS:
		return (lcdstate->lcdintrawstatus	& 0xFFFFFFFF);
	case LCD_INTENSET:
		return (lcdstate->lcdintenable		& 0x0000001F);
	case LCD_FRAMECOUNT:
		return (lcdstate->lcdframecount		& 0x000100FF);
	}
	
	return 0;
}

static void em1d_lcdc_write(void *opaque, target_phys_addr_t offset, uint32_t value)
{
	LCD_STATE*			lcdstate;
	
	//printf("%s:%d[0x%04x:0x%08x]\n", __FUNCTION__, __LINE__, offset, value);
	lcdstate = (LCD_STATE*)opaque;
	switch(offset)
	{
	case LCD_CONTROL:		// 0x0000
	case LCD_QOS:			// 0x0004
	case LCD_DATAREQ:		// 
		break;
	case LCD_LCDOUT:		// 
		lcdstate->lcdout		= (value & 0x00000001);
		lcdstate->lcdstatus		&= 0xFFFFFFFE;
		lcdstate->lcdstatus		|= (lcdstate->lcdout);
		break;
	case LCD_BUSSEL:		// 0x0014
		lcdstate->lcdbussel		= (value & 0x00000007);
		lcdstate->lcdstatus		&= 0xFFFFF8F2;
		lcdstate->lcdstatus		|= (lcdstate->lcdbussel << 8);
		break;
	case LCD_BACKCOLOR:		// 0x001C
		lcdstate->lcdbackcolor	= (value & 0x003F3F3F);
		break;
	case LCD_AREAADR:		// 0x0020
		lcdstate->lcdareaadr	= (value & 0xFFFFFFFC);
		break;
	case LCD_HOFFSET:		// 0x0024
		lcdstate->lcdhoffset	= (value & 0x00001FFC);
		break;
	case LCD_IFORMAT:		// 0x0028
		lcdstate->lcdiformat	= (value & 0x00000001);
		break;
	////////////////////////////////////////////////////////////////////////////
	case LCD_HTOTAL:		// 0x0030
		lcdstate->lcdhtotal		= (value & 0x00000FFF);
		break;
	case LCD_HAREA:			// 0x0034
		lcdstate->lcdharea		= (value & 0x000007FE);
		break;
	case LCD_VTOTAL:		// 0x0040
		lcdstate->lcdvtotal		= (value & 0x00000FFF);
		break;
	case LCD_VAREA:			// 0x0044
		lcdstate->lcdvarea		= (value & 0x000007FF);
		break;
	////////////////////////////////////////////////////////////////////////////
	/*
	case LCD_HEDGE1:
	case LCD_HEDGE2:
	case LCD_VEDGE1:
	case LCD_VEDGE2:
	*/
	case LCD_INTENSET:
		lcdstate->lcdintenable	|= (value & 0x0000001F);
		break;
	case LCD_INTENCLR:
		lcdstate->lcdintenable	&= ~(value & 0x0000001F);
		break;
	case LCD_INTFFCLR:
		lcdstate->lcdintresult	&= ~(value & 0x0000001F);
		break;
	case LCD_FRAMECOUNT:
		break;
	}
}

/********************************************************************************/
static CPUReadMemoryFunc * const em1d_lcdc_readfn[] = {
    em1d_lcdc_read,
    em1d_lcdc_read,
    em1d_lcdc_read,
};

static CPUWriteMemoryFunc * const em1d_lcdc_writefn[] = {
    em1d_lcdc_write,
    em1d_lcdc_write,
    em1d_lcdc_write,
};

static int em1d_lcdc_init(SysBusDevice *dev)
{
	int					iomemtype;
	LCD_STATE*			lcdstate;
	
	// memory range of lcd
	lcdstate = FROM_SYSBUS(LCD_STATE, dev);
	iomemtype = cpu_register_io_memory(em1d_lcdc_readfn, em1d_lcdc_writefn, lcdstate);
	
	sysbus_init_mmio(dev, 0x1000, iomemtype);
	sysbus_init_irq(dev, &lcdstate->irq);
	
	// create one display state object and add it to display_state
	// (w:640 h:480 bpp:4(byte) lz:4w pf:[bpp:32(bit) bpp:4(byte) depth:32(bit)])
	lcdstate->dstate = graphic_console_init(em1d_update_display, 			// hw_update
											em1d_invalidate_display, 		// hw_invalidate
											NULL, 							// hw_screen_dump
											NULL, 							// hw_text_update
											lcdstate);						// hw
	return 0;
}

static void em1d_lcdc_reg(void)
{
	sysbus_register_dev("tef_em1d_lcdc", sizeof(LCD_STATE), em1d_lcdc_init);
}

device_init(em1d_lcdc_reg)

