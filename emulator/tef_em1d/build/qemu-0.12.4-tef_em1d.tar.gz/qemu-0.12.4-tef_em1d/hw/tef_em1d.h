#ifndef __TEF_EM1D_H___
#define __TEF_EM1D_H___

#define TEF_EM1D_DEBUG		1

// RTC
int S35392_init(i2c_bus* i2c);

#endif