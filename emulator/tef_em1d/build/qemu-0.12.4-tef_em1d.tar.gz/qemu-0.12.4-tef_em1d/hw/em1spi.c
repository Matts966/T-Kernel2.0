/*
 * em1 spi bus inplement.
 * 
 * Copyright (c) 2011 UNL
 * Written by Lei Tan
 *
 * This code is licenced under the LGPL.
 *
 */
#include "sysbus.h"
#include "em1spi.h"

#define DEBUG_SPI			0

#if DEBUG_SPI
#define SPI_P_DBG(fmt, ...) printf("SPI:%s: " fmt, __FUNCTION__, ## __VA_ARGS__)
#else
#define SPI_P_DBG(fmt, ...) ((void)0)
#endif

#define MAX_CHANNELS	6


#define MODE_CK_PHAS_MASK	0x00002000
#define MODE_NB_A_MASK		0x00001F00
#define MODE_CS_SELA_MASK	0x00000070
#define MODE_M_S_MASK		0x00000002
#define MODE_DMA_MASK		0x00000001
#define MODE_ALL_MASK		(MODE_CK_PHAS_MASK | \
							 MODE_NB_A_MASK | \
							 MODE_CS_SELA_MASK | \
							 MODE_M_S_MASK | \
							 MODE_DMA_MASK)
							 
#define POL_CS5_POL_MASK	0x00080000
#define POL_CS4_POL_MASK	0x00010000
#define POL_CS3_POL_MASK	0x00000200
#define POL_CS2_POL_MASK	0x00000040
#define POL_CS1_POL_MASK	0x00000008
#define POL_CS0_POL_MASK	0x00000001
#define POL_ALL_MASK		0x003FFFFF

#define CTL_RST_MASK		0x00000100
#define CTL_WRT_MASK		0x00000008
#define CTL_RD_MASK			0x00000004
#define CTL_STOP_MASK		0x00000002
#define CTL_START_MASK		0x00000001
#define CTL_ALL_MASK		(CTL_RST_MASK | \
							 CTL_WRT_MASK | \
							 CTL_RD_MASK | \
							 CTL_STOP_MASK | \
							 CTL_START_MASK)

#define INT_TX_STOP_RAW		0x00000040
#define INT_RX_STOP_RAW		0x00000020
#define INT_TERR_RAW		0x00000010
#define INT_RDV_RAW			0x00000008
#define INT_END_RAW			0x00000004
#define INT_TX_UDR_RAW		0x00000002
#define INT_RX_OVR_RAW		0x00000001

#define TIECS_R_CS5_MASK	0x00000020
#define TIECS_R_CS4_MASK	0x00000010
#define TIECS_R_CS3_MASK	0x00000008
#define TIECS_R_CS2_MASK	0x00000004
#define TIECS_R_CS1_MASK	0x00000002
#define TIECS_R_CS0_MASK	0x00000001
#define TIECS_ALL_MASK		0x0000003F

static const uint32_t pol_mask[MAX_CHANNELS] = {
	POL_CS0_POL_MASK,
	POL_CS1_POL_MASK,
	POL_CS2_POL_MASK,
	POL_CS3_POL_MASK,
	POL_CS4_POL_MASK,
	POL_CS5_POL_MASK
};

// cs direction: 0: Hi true, != 0: Lo true
static const uint32_t pol_dir[MAX_CHANNELS] = {
	0,
	POL_CS1_POL_MASK,
	0,
	0,
	0,
	0
};

typedef struct em1_spi_state{
	SysBusDevice busdev;
	qemu_irq irq;
	
	uint32_t mode;
	uint32_t pol;
	uint32_t ctrl;
	uint32_t tx_data;
	uint32_t int_status;
	uint32_t int_mask;
	uint32_t ctrl2;
	uint32_t tiecs;
	
	int cs;			// -1: error, >= 0: cs channel.
	spi_slave *dev[MAX_CHANNELS];
} em1_spi_state;

static void cal_cs(em1_spi_state *s){
	int i;

	for(i = 0; i < MAX_CHANNELS; i++){
		if(((s->tiecs & (1 << i)) && ((s->pol ^ pol_dir[i]) & pol_mask[i]))){
			break;
		}
	}
	
	if(i == MAX_CHANNELS && (s->tiecs & (1 << ((s->mode & MODE_CS_SELA_MASK) >> 4))) == 0){
		i = (s->mode & MODE_CS_SELA_MASK) >> 4;
	}
	
	if(i < MAX_CHANNELS){
		if(i != s->cs && s->cs != -1 && s->dev[s->cs]){
			s->dev[s->cs]->event_fp(s->dev[s->cs], SPI_EVT_CS_DISABLE);
		}
		
		if(i != s->cs && s->dev[i]){
			s->dev[i]->event_fp(s->dev[i], SPI_EVT_CS_ENABLE);
		}
		
		s->cs = i;
	}
	else{
		if(s->cs != -1 && s->dev[s->cs]){
			s->dev[s->cs]->event_fp(s->dev[s->cs], SPI_EVT_CS_DISABLE);
		}
		
		s->cs = -1;
	}
	
	SPI_P_DBG("cs = %d\n", s->cs);
	return;
}

static void em1_spi_reset(void *opaque){
	em1_spi_state *s = (em1_spi_state *)opaque;
	
	s->mode = 0x00000002;
	s->pol = 0x00007000;
	s->ctrl = 0x00008040;
	s->int_status = 0;
	s->int_mask = 0;
	s->ctrl2 = 0;
	s->tiecs = 0;
	
	cal_cs(s);
	memset(s->dev, 0, sizeof(spi_slave *) * MAX_CHANNELS);
}

static uint32_t em1_spi_read(void *opaque, target_phys_addr_t offset){
	em1_spi_state *s = (em1_spi_state *)opaque;
	uint32_t data = 0;
	
	switch(offset){
		case 0x00:
			data = s->mode;
			break;
		case 0x04:
			data = s->pol;
			break;
		case 0x14:
			if(s->dev[s->cs]){
				data = s->dev[s->cs]->rx_fp(s->dev[s->cs]);
				qemu_set_irq(s->irq, 0);
			}
			break;
		case 0x18:
			data = s->int_status & s->int_mask;
			break;
		case 0x1C:
			data = s->int_status;
			break;
		case 0x20:
			data = s->int_mask;
			break;
		case 0x38:
			data = s->tiecs;
			break;
		default:
			break;
	}
	SPI_P_DBG("offset=0x%02x data=0x%08x\n", offset, data);
	return data;
}

static void em1_spi_write(void *opaque, target_phys_addr_t offset,
								uint32_t value){
	em1_spi_state *s = (em1_spi_state *)opaque;
	
	SPI_P_DBG("offset=0x%02x data=0x%08x\n", offset, value);
	switch(offset){
		case 0x00:
			s->mode = value & MODE_ALL_MASK;
			cal_cs(s);
			break;
		case 0x04:
			s->pol = value & POL_ALL_MASK;
			cal_cs(s);
			break;
		case 0x08:
			if((value & CTL_WRT_MASK) && (value & CTL_START_MASK) && s->dev[s->cs]){
				s->dev[s->cs]->tx_fp(s->dev[s->cs], s->tx_data);
				s->int_status |= INT_END_RAW;
				if(s->int_mask & INT_END_RAW){
					qemu_set_irq(s->irq, 1);
				}
			}
			else if((value & CTL_RD_MASK) && (value & CTL_START_MASK) && s->dev[s->cs]){
				s->int_status |= (INT_RDV_RAW | INT_END_RAW);
				if(s->int_mask & INT_RDV_RAW || s->int_mask & INT_END_RAW){
					qemu_set_irq(s->irq, 1);
				}
			}
			break;
		case 0x10:
			s->tx_data = value;
			break;
		case 0x20:
			s->int_mask |= value;
			break;
		case 0x24:
			s->int_mask &= ~value;
			break;
		case 0x28:
			s->int_status &= ~value;
			if(!(s->int_status & s->int_mask)){
				qemu_set_irq(s->irq, 0);
			}
			break;
		case 0x34:
			s->ctrl2 = value;
			break;
		case 0x38:
			s->tiecs = value & TIECS_ALL_MASK;
			cal_cs(s);
		default:
			break;
	}
}

static CPUReadMemoryFunc * const em1_spi_readfn[] = {
   em1_spi_read,
   em1_spi_read,
   em1_spi_read
};

static CPUWriteMemoryFunc * const em1_spi_writefn[] = {
   em1_spi_write,
   em1_spi_write,
   em1_spi_write
};

static int em1_spi_init(SysBusDevice * dev){
	em1_spi_state *s = FROM_SYSBUS(em1_spi_state, dev);
	int iomemtype;
	
	sysbus_init_irq(dev, &s->irq);
	
	iomemtype = cpu_register_io_memory(em1_spi_readfn,
									   em1_spi_writefn, s);
	sysbus_init_mmio(dev, 0x100, iomemtype);
	
	em1_spi_reset(s);
	
	return 0;
}

void em1spi_add_slave(void *opaque, spi_slave *dev, int cs_x){
	em1_spi_state *s = (em1_spi_state *)opaque;
	if(cs_x < MAX_CHANNELS && cs_x >= 0){
		s->dev[cs_x] = dev;
	}
	
	return;
}

static void em1spi_register_devices(void)
{
	sysbus_register_dev("em1spi", sizeof(em1_spi_state), em1_spi_init);
}

device_init(em1spi_register_devices)