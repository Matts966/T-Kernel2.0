/*
 * da9052 PMIC dummy.
 * 
 * Copyright (c) 2011 UNL
 * Written by Lei Tan
 *
 * This code is licenced under the LGPL.
 *
 */
#include "hw.h"
#include "console.h"
#include "qdev.h"
#include "em1spi.h"
#include "da9052.h"

#define DEBUG_PMIC 0

#if DEBUG_PMIC
#define DA9052_P_DBG(fmt, ...) printf("DA9052:%s: " fmt, __FUNCTION__, ## __VA_ARGS__)
#else
#define DA9052_P_DBG(fmt, ...) ((void)0)
#endif

#define DA9052_READ			0x00000001
#define DA9052_WRITE		0x00000002

typedef struct{
	spi_slave ss;
	
	int address;
	int rw;
	int step;
	qemu_irq tpirq;
	
	int x;
	int y;
	int state;
	uint8_t eventb;
	
	int xmin;
	int xmax;
	int ymin;
	int ymax;
	int xchg;
} da9052_states;

static void tp_event(void *opaque,
			     int x, int y, int dz, int buttons_state){
	da9052_states *ds = (da9052_states *) opaque;
	
	if(buttons_state){
		x = ds->xmin + (x * (ds->xmax - ds->xmin) / 32768);
		y = ds->ymin + (y * (ds->ymax - ds->ymin) / 32768);
		ds->x = (ds->xchg == 0) ? x : y;
		ds->y = (ds->xchg == 0) ? y : x;
		ds->state = buttons_state;
		ds->eventb |= 0x80;
		ds->eventb |= 0x40;
		qemu_set_irq(ds->tpirq, 1);
		DA9052_P_DBG("x = %d, y = %d, states = %d\n", ds->x, ds->y, buttons_state);
	}
	else{
		ds->state = buttons_state;
		if(ds->eventb & 0x40){
			x = ds->xmin + (x * (ds->xmax - ds->xmin) / 32768);
			y = ds->ymin + (y * (ds->ymax - ds->ymin) / 32768);
			ds->x = (ds->xchg == 0) ? x : y;
			ds->y = (ds->xchg == 0) ? y : x;
			ds->eventb |= 0x80;
			ds->eventb &= 0xBF;
			qemu_set_irq(ds->tpirq, 1); // The hard will trigger pendown interrupt even after the touch is over.
			DA9052_P_DBG("x = %d, y = %d, states = %d\n", ds->x, ds->y, buttons_state);
		}
		else{
			ds->eventb |= 0x80;
			qemu_set_irq(ds->tpirq, 0);
		}
	}
}

static uint32_t da9052_rx(void *sp){
	da9052_states *ds = (da9052_states *) sp;
	uint32_t data = 0;
	
	if(ds->rw == DA9052_READ){
		if(ds->step > 0){
			switch(ds->address){
				case 6:
					data = ds->eventb;
					ds->eventb &= 0x7F;
					break;
				case 107:
					data = (ds->x & 0x03FC) >> 2;
					break;
				case 108:
					data = (ds->y & 0x03FC) >> 2;
					break;
				case 109:
					data = (ds->x & 0x3) | ((ds->y & 0x3) << 2) | (ds->state << 6);
					break;
				default:
					break;
			}
		}
		else{
			ds->step ++;
		}
	}
	DA9052_P_DBG("address: %d data = 0x%02X\n", ds->address, data);
	return data;
}

static void da9052_tx(void *sp, uint32_t data){
	da9052_states *ds = (da9052_states *) sp;
	
	if(ds->rw == 0){
		ds->address = data >> 1;
		if(data & 1){
			ds->rw = DA9052_READ;
		}
		else{
			ds->rw = DA9052_WRITE;
		}
	}
	else if(ds->rw == DA9052_WRITE){
		switch(ds->address){
			case 0x06:
/*				ds->eventb &= ~data;
				if(!(ds->eventb & 0x40)){
					qemu_set_irq(ds->tpirq, 0);
				}*/
				break;
			case 0x0F:
				if(data == 0x60){
					qemu_system_shutdown_request();
				}
				else if(data == 0xAC){
					qemu_system_reset();
				}
				break;
			default:
				break;
		}
	}
	DA9052_P_DBG("data = 0x%08x\n", data);
}

static void da9052_event(void *sp, uint32_t event){
	da9052_states *ds = (da9052_states *) sp;
	
	switch(event){
		case SPI_EVT_CS_ENABLE:
			ds->address = 0;
			ds->rw = 0;
			ds->step = 0;
			break;
		case SPI_EVT_CS_DISABLE:
			ds->address = 0;
			ds->rw = 0;
			ds->step = 0;
			break;
		default:
			break;
	}
	DA9052_P_DBG("event=%d\n", event);
}

spi_slave *da9052_create(qemu_irq irq, int xmin, int xmax, int ymin, int ymax, int xchg){
	da9052_states *ds = (da9052_states *) qemu_mallocz(sizeof(da9052_states));
	
	ds->ss.rx_fp = da9052_rx;
	ds->ss.tx_fp = da9052_tx;
	ds->ss.event_fp = da9052_event;

	printf("tp: %d %d %d %d %d\n", xmin, xmax, ymin, ymax, xchg);

	ds->xmin = xmin;
	ds->xmax = xmax;
	ds->ymin = ymin;
	ds->ymax = ymax;
	ds->xchg = xchg;
	ds->tpirq = irq;
	qemu_add_mouse_event_handler(tp_event, ds, 1, "Touch panel");
	
	return (spi_slave *)ds;
}