/*
 * r4581nb spi inplement.
 * 
 * Copyright (c) 2011 UNL
 * Written by Lei Tan
 *
 * This code is licenced under the LGPL.
 *
 */

#include "r4581nb.h"

#define DEBUG_R4581NB			0

#if DEBUG_R4581NB
#define R4581NB_P_DBG(fmt, ...) printf("R4581NB:%s: " fmt, __FUNCTION__, ## __VA_ARGS__)
#else
#define R4581NB_P_DBG(fmt, ...) ((void)0)
#endif

typedef struct {
	spi_slave ss;
	
	struct tm	now;
	time_t		offset;
	
	int			cur_address;
	int			rw;
	
	uint8_t		ext;
	uint8_t		flg;
	uint8_t		ctl;
} r4581nb_states;

static uint32_t r4851nb_rx(void *sp){
	r4581nb_states *rtcs = (r4581nb_states *) sp;
	uint32_t data = 0;
	
	if(rtcs->rw){
		qemu_get_timedate(&rtcs->now, rtcs->offset);
		switch(rtcs->cur_address){
			case 0:
				data = to_bcd(rtcs->now.tm_sec);
				break;
			case 1:
				data = to_bcd(rtcs->now.tm_min);
				break;
			case 2:
				data = to_bcd(rtcs->now.tm_hour);
				break;
			case 3:
				data = 1 << (to_bcd(rtcs->now.tm_wday) - 1);
				break;
			case 4:
				data = to_bcd(rtcs->now.tm_mday);
				break;
			case 5:
				data = to_bcd(rtcs->now.tm_mon + 1);
				break;
			case 6:
				data = to_bcd(rtcs->now.tm_year - 100);
				break;
			case 0xd:
				data = rtcs->ext;
				break;
			case 0xe:
				data = rtcs->flg;
				break;
			case 0xf:
				data = rtcs->ctl;
				break;
			default:
				break;
		}
		R4581NB_P_DBG("address = %d, data = %d\n", rtcs->cur_address, from_bcd(data));
	}
	
	return data;
}

static void r4851nb_tx(void *sp, uint32_t data){
	r4581nb_states *rtcs = (r4581nb_states *) sp;
	
	if(rtcs->cur_address == -1){	// address
		rtcs->cur_address = data & 0xF;
		rtcs->rw = (data & 0xE0) >> 7;
	}
	else{							// write.
		if(rtcs->rw == 0){
			R4581NB_P_DBG("address = %d, data = %d\n", rtcs->cur_address, from_bcd(data));
			qemu_get_timedate(&rtcs->now, rtcs->offset);
			switch(rtcs->cur_address){
				case 0:
					rtcs->now.tm_sec = from_bcd(data & 0x7F);
					break;
				case 1:
					rtcs->now.tm_min = from_bcd(data & 0x7F);
					break;
				case 2:
					rtcs->now.tm_hour = from_bcd(data & 0x3F);
					break;
				case 3:
					for(rtcs->now.tm_wday = 0; data > 1; data >>= 1, rtcs->now.tm_wday++);
					break;
				case 4:
					rtcs->now.tm_mday = from_bcd(data & 0x3F);
					break;
				case 5:
					rtcs->now.tm_mon = from_bcd(data & 0x1F) - 1;
					break;
				case 6:
					rtcs->now.tm_year = from_bcd(data) + 100;
					break;
				case 0xd:
					rtcs->ext = data;
					break;
				case 0xe:
					rtcs->flg = data;
					break;
				case 0xf:
					rtcs->ctl = data;
					break;
				default:
					break;
			}
			rtcs->offset = qemu_timedate_diff(&rtcs->now);
		}
	}
}

static void r4851nb_event(void*sp, uint32_t event){
	r4581nb_states *rtcs = (r4581nb_states *) sp;
	
	switch(event){
		case SPI_EVT_CS_ENABLE:
			break;
		case SPI_EVT_CS_DISABLE:
			rtcs->cur_address = -1;
			break;
		default:
			break;
	}
}

spi_slave *r4581nb_create(){
	r4581nb_states *rtcs = qemu_mallocz(sizeof(r4581nb_states));
	
	rtcs->ss.rx_fp = r4851nb_rx;
	rtcs->ss.tx_fp = r4851nb_tx;
	rtcs->ss.event_fp = r4851nb_event;
	
	rtcs->cur_address = -1;
	rtcs->offset = 0;
	
	return (spi_slave *) rtcs;
}