
//////////////////////////////////////////////////////////////////////////////////////////////////////
#if DEPTH == 8
#define COPY_PIXEL(to , from)		(*to = from); (to ++)
#elif DEPTH == 15 || DEPTH == 16
#define COPY_PIXEL(to , from)		(*(uint16_t *)to = from); (to += 2)
#elif DEPTH == 24
#define COPY_PIXEL(to , from)		(*(uint16_t *)to = from); (*(to + 2) = ((from)>>16)); (to += 3)
#elif DEPTH == 32
#define COPY_PIXEL(to , from)		(*(uint32_t *)to = from); (to += 4)
#else
#error unsupport depth
#endif

/*
 * 16-bit color
 */
static void glue(draw_line16_, DEPTH)(void *opaque, uint8_t *d, const uint8_t *s, int width, int deststep)
{
	uint8_t		r, g, b;
	uint16_t	pixel;
	
	while(width-- > 0)
	{
		// one pixel from source image(2bytes)
		pixel	= *(uint16_t *)s;
		
		b		= ((pixel >> 0 ) & 0x1f) << 3; // B: BBBBB000
		g		= ((pixel >> 5 ) & 0x3f) << 2; // G: GGGGGG00
		r		= ((pixel >> 11) & 0x3f) << 3; // R: RRRRR000
		
		// copy data to dest address
		COPY_PIXEL(d, glue(rgb_to_pixel, DEPTH)(r, g, b));
		
		s		+= 2; // 16 bit
	}
}

/*
 * 18-bit color
 */
static void glue(draw_line18_, DEPTH)(void *opaque, uint8_t *d, const uint8_t *s, int width, int deststep)
{
	// TODO: later
}

#undef DEPTH
#undef COPY_PIXEL

