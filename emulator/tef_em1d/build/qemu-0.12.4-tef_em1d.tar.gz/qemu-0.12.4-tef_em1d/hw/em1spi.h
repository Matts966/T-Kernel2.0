/*
 * em1 spi bus inplement.
 * 
 * Copyright (c) 2011 UNL
 * Written by Lei Tan
 *
 * This code is licenced under the LGPL.
 *
 */

#ifndef __QEMU_EM1SPI_H_
#define __QEMU_EM1SPI_H_

#include "qdev.h"

#define SPI_EVT_CS_ENABLE		1
#define SPI_EVT_CS_DISABLE		0


// slave to master.
typedef uint32_t (*spi_rx)(void *sp);
// master to slave.
typedef void (*spi_tx)(void *sp, uint32_t data);
// event function.
typedef void (*spi_event)(void*sp, uint32_t event);

typedef struct {
	spi_rx rx_fp;
	spi_tx tx_fp;
	spi_event event_fp;
} spi_slave;

void em1spi_add_slave(void *opaque, spi_slave *dev, int cs_x);

#endif //__QEMU_EM1SPI_H_
