/*
 * em1 GIO inplement.
 * 
 * Copyright (c) 2011 UNL
 * Written by Lei Tan
 *
 * This code is licenced under the LGPL.
 *
 */
#include "sysbus.h"

#define DEBUG_EM1_GIO 0

#if DEBUG_EM1_GIO
#define GIO_P_DBG(fmt, ...) printf("EM1GIO:%s: " fmt, __FUNCTION__, ## __VA_ARGS__)
#else
#define GIO_P_DBG(fmt, ...) ((void)0)
#endif

#define GIO_IRQ_CNT		8

// GIO device, (dip switch: SW1 = OFF::AutoBoot (GIO_P4 = 1))
typedef struct gio_state{
	SysBusDevice busdev;
	
	uint32_t iia[4];
	uint32_t raw[4];
	uint32_t mask[4];
	qemu_irq gio_irq[8];
} gio_state;

static void gio_update_irq(gio_state *s){
	int i;
	uint32_t tmp;
	
	for(i = 0; i < 4; i++){
		tmp = s->raw[i] & s->mask[i] & s->iia[i];
		if(tmp & 0x0000FFFF){
			qemu_set_irq(s->gio_irq[2 * i], 1);
			GIO_P_DBG("gio_int(%d) -> high\n", 2 * i);
		}
		else{
			qemu_set_irq(s->gio_irq[2 * i], 0);
			GIO_P_DBG("gio_int(%d) -> low\n", 2 * i);
		}
		
		if(tmp & 0xFFFF0000){
			qemu_set_irq(s->gio_irq[2 * i + 1], 1);
			GIO_P_DBG("gio_int(%d) -> high\n", 2 * i + 1);
		}
		else{
			qemu_set_irq(s->gio_irq[2 * i + 1], 0);
			GIO_P_DBG("gio_int(%d) -> low\n", 2 * i + 1);
		}
		//GIO_P_DBG("gio_int(%d): raw = 0x%08X mask = 0x%08X iia= 0x%08X\n", i, s->raw[i], s->mask[i], s->iia[i]);
	}
}

static void gio_set_irq(void *opaque, int irq, int level){
	gio_state *s = FROM_SYSBUS(gio_state, opaque);
	int group = irq >> 5;
	uint32_t line = 1 << (irq % 32);
	
	if(s->iia[group] & line){
		if(level > 0){
			s->raw[group] |= line;
		}
		else{
			s->raw[group] &= ~line;
		}
	}
	GIO_P_DBG("irq: line = %d, level = %d\n", irq, level);
	gio_update_irq(s);
}

static uint32_t gio_read(void *opaque, target_phys_addr_t offset){
	gio_state *s = FROM_SYSBUS(gio_state, opaque);
	uint32_t data = 0;
	
	switch(offset){
		case 0x0010:			// GIO_I_L
			//data = 0x00000010;
			break;
		case 0x0014:			// GIO_IIA_L (0-31)
			data = s->iia[0];
			break;
		case 0x001C:			// GIO_IIM_L
			data = s->mask[0];
			break;
		case 0x0020:			// GIO_RAW_L
			data = s->raw[0];
			break;
		case 0x0024:			// GIO_MST_L
			data = s->raw[0] & s->mask[0];
			break;
		case 0x0054:			// GIO_IIA_H (32-63)
			data = s->iia[1];
			break;
		case 0x005C:			// GIO_IIM_H
			data = s->mask[1];
			break;
		case 0x0060:			// GIO_RAW_H
			data = s->raw[1];
			break;
		case 0x0064:			// GIO_MST_H
			data = s->raw[1] & s->mask[1]; //0x00000200;
			break;
		case 0x0094:			// GIO_IIA_HH (64-95)
			data = s->iia[2];
			break;
		case 0x009C:			// GIO_IIM_HH
			data = s->mask[2];
			break;
		case 0x00A0:			// GIO_RAW_HH
			data = s->raw[2];
			break;
		case 0x00A4:			// GIO_MST_HH
			data = s->raw[2] & s->mask[2];
			break;
		case 0x0214:			// GIO_IIA_HHH (96-127)
			data = s->iia[3];
			break;
		case 0x021C:			// GIO_IIM_HHH
			data = s->mask[3];
			break;
		case 0x0220:			// GIO_RAW_HHH
			data = s->raw[3];
			break;
		case 0x0224:			// GIO_MST_HHH
			data = s->raw[3] & s->mask[3];
			break;
		default:
			break;
	}
	
	GIO_P_DBG("read 0x%08X value = 0x%08x\n", offset, data);
	
	return data;
}

static void gio_write(void *opaque, target_phys_addr_t offset, uint32_t data){
	gio_state *s = FROM_SYSBUS(gio_state, opaque);
	
	GIO_P_DBG("write 0x%08X data 0x%08X\n", offset, data);
	switch(offset){
		case 0x0014:			// GIO_IIA_L (0-31)
			s->iia[0] = data;
			gio_update_irq(s);
			break;
		case 0x0018:			// GIO_IEN_L
			s->mask[0] |= data;
			gio_update_irq(s);
			break;
		case 0x001C:			// GIO_IDS_L
			s->mask[0] &= ~data;
			gio_update_irq(s);
			break;
		case 0x0028:			// GIO_IIR_L
			s->raw[0] &= ~data;
			gio_update_irq(s);
			break;
		case 0x0054:			// GIO_IIA_H (32-63)
			s->iia[1] = data;
			gio_update_irq(s);
			break;
		case 0x0058:			// GIO_IEN_H
			s->mask[1] |= data;
			gio_update_irq(s);
			break;
		case 0x005C:			// GIO_IDS_H
			s->mask[1] &= ~data;
			gio_update_irq(s);
			break;
		case 0x0068:			// GIO_IIR_H
			s->raw[1] &= ~data;
			gio_update_irq(s);
			break;
		case 0x0094:			// GIO_IIA_HH (64-95)
			s->iia[2] = data;
			gio_update_irq(s);
			break;
		case 0x0098:			// GIO_IEN_HH
			s->mask[2] |= data;
			gio_update_irq(s);
			break;
		case 0x009C:			// GIO_IDS_HH
			s->mask[2] &= ~data;
			gio_update_irq(s);
			break;
		case 0x00A8:			// GIO_IIR_HH
			s->raw[2] &= ~data;
			gio_update_irq(s);
			break;
		case 0x00214:			// GIO_IIA_HHH (96-127)
			s->iia[3] = data;
			gio_update_irq(s);
			break;
		case 0x00218:			// GIO_IEN_HHH
			s->mask[3] |= data;
			gio_update_irq(s);
			break;
		case 0x021C:			// GIO_IDS_HHH
			s->mask[3] &= ~data;
			gio_update_irq(s);
			break;
		case 0x0228:			// GIO_IIR_HHH
			s->raw[3] &= ~data;
			gio_update_irq(s);
			break;
		default:
			break;
	}
}

static CPUReadMemoryFunc * const gio_readfn[] = {
   gio_read,
   gio_read,
   gio_read
};

static CPUWriteMemoryFunc * const gio_writefn[] = {
   gio_write,
   gio_write,
   gio_write
};

static int gio_init(SysBusDevice *dev){
	gio_state *s = FROM_SYSBUS(gio_state, dev);
    int iomemtype, i;
	
	iomemtype = cpu_register_io_memory(gio_readfn,
                                       gio_writefn, s);
    sysbus_init_mmio(dev, 0x00010000, iomemtype);
    
    qdev_init_gpio_in(&dev->qdev, gio_set_irq, 128);
    for(i = 0; i < GIO_IRQ_CNT; i++){
    	sysbus_init_irq(dev, &s->gio_irq[i]);
    }
    
    return 0;
}

static void em1gio_register_devices(void){
	sysbus_register_dev("em1gio", sizeof(gio_state), gio_init);
}

device_init(em1gio_register_devices)