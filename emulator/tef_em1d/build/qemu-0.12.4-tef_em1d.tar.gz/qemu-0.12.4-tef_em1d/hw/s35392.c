#include "i2c.h"


#define DEBUG_TRC			0
#ifndef TRC_P_DBG
#if DEBUG_TRC
#define TRC_P_DBG(fmt, ...) printf("TRC:%s:%d " fmt, __FUNCTION__, __LINE__, ## __VA_ARGS__)
#else
#define TRC_P_DBG(fmt, ...) ((void)0)
#endif
#endif


typedef struct
{
	int			step;
	struct tm	now;
    time_t		offset;

	uint8_t		status1;
	uint8_t		status2;
	uint8_t		time[7];
}S35392_State;

typedef struct {
	i2c_slave		i2c;
	S35392_State*	parent;
}S35392_Slave;


int S35392_init(i2c_bus* i2c);

static uint8_t bitrevUB(uint8_t n)
{
	n = ((n >> 1) & 0x55) | ((n << 1) & 0xaa);
	n = ((n >> 2) & 0x33) | ((n << 2) & 0xcc);
	n = ((n >> 4) & 0x0f) | ((n << 4) & 0xf0);

	return n;
}

static void S35392_event(i2c_slave *i2c, enum i2c_event event)
{
	S35392_Slave* d = FROM_I2C_SLAVE(S35392_Slave, i2c);
	S35392_State* s = d->parent;

	TRC_P_DBG("Address:0x%x Event:%d\n", i2c->address, event);
	switch (event)
	{
	case I2C_START_RECV:
		s->step = 0;
		if (0x32 == i2c->address)
		{
			TRC_P_DBG("Offset:%d\n", s->offset);
			qemu_get_timedate(&s->now, s->offset);
			TRC_P_DBG("Date:%d,%d,%d,%d,%d,%d Week:%d\n", s->now.tm_year, s->now.tm_mon, s->now.tm_mday,
			          s->now.tm_hour, s->now.tm_min, s->now.tm_sec, s->now.tm_wday);

			s->time[6] = to_bcd(s->now.tm_sec);
			s->time[5] = to_bcd(s->now.tm_min);
			if (s->time[4] & 0x40) {
				s->time[4] = (to_bcd((s->now.tm_hour % 12)) + 1) | 0x40;
				if (s->now.tm_hour >= 12) {
					s->time[4] |= 0x20;
				}
			} else {
				s->time[4] = to_bcd(s->now.tm_hour);
			}
			s->time[3] = to_bcd(s->now.tm_wday) + 1;
			s->time[2] = to_bcd(s->now.tm_mday);
			s->time[1] = to_bcd(s->now.tm_mon) + 1;
			s->time[0] = to_bcd(s->now.tm_year - 100);
			
			int i;
			for (i = 0; i < 7; i++)
			s->time[i] = bitrevUB(s->time[i]);
		}
		break;
	case I2C_START_SEND:
		s->step = 0;
		break;
	case I2C_FINISH:
		if (0x32 == i2c->address)
		{
	        s->offset = qemu_timedate_diff(&s->now);
			TRC_P_DBG("Offset:%d", s->offset);
		}
	default:
		break;
	}
}

static int S35392_recv(i2c_slave *i2c)
{
	S35392_Slave* d = FROM_I2C_SLAVE(S35392_Slave, i2c);
	S35392_State* s = d->parent;
	uint8_t ret = 0;

	switch (i2c->address)
	{
	case 0x30:
		ret = s->status1;
		break;
	case 0x31:
		ret = s->status2;
		break;
	case 0x32:
		if (s->step > 6)
			TRC_P_DBG("ERROR!! Step:%d\n", s->step);
		else
			ret = s->time[s->step++];
		break;
	default:
		break;
	}

	TRC_P_DBG("Address:0x%x Ret:0x%x\n", i2c->address, ret);
	return ret;
}

static int S35392_send(i2c_slave *i2c, uint8_t data)
{
	S35392_Slave* d = FROM_I2C_SLAVE(S35392_Slave, i2c);
	S35392_State* s = d->parent;

	TRC_P_DBG("Address:0x%x data:0x%x\n", i2c->address, data);
	switch (i2c->address)
	{
	case 0x32:
		data = bitrevUB(data);
		switch (s->step)
		{
			case 6:
				s->now.tm_sec = from_bcd(data & 0x7f);
				break;
			case 5:
				s->now.tm_min = from_bcd(data & 0x7f);
				break;
			case 4:
				if (data & 0x40) {
					if (data & 0x20) {
						data = from_bcd(data & 0x4f) + 11;
					} else {
						data = from_bcd(data & 0x1f) - 1;
					}
				} else {
					data = from_bcd(data);
				}
				s->now.tm_hour = data;
				break;
			case 3:
				s->now.tm_wday = from_bcd(data & 7) - 1;
				break;
			case 2:
				s->now.tm_mday = from_bcd(data & 0x3f);
				break;
			case 1:
				s->now.tm_mon = from_bcd(data & 0x1f) - 1;
			case 0:
				s->now.tm_year = from_bcd(data) + 100;
				break;
		}
		TRC_P_DBG("Date:%d,%d,%d,%d,%d,%d Week:%d\n", s->now.tm_year, s->now.tm_mon, s->now.tm_mday,
		          s->now.tm_hour, s->now.tm_min, s->now.tm_sec, s->now.tm_wday);
		break;
	}

	s->step += 1;
	return 0;
}

static int S35392_slave_init(i2c_slave *i2c)
{
	TRC_P_DBG("Slave:0x%x\n", i2c);
	return 0;
}

int S35392_init(i2c_bus* i2c)
{
	S35392_Slave* s;
    S35392_State* dev = qemu_mallocz(sizeof(S35392_State));

	s = FROM_I2C_SLAVE(S35392_Slave, (i2c_slave*)i2c_create_slave(i2c, "S35392", 0x30));
	s->parent = dev;
	TRC_P_DBG("Slave:0x%x Parent:0x%x\n", s, dev);
	s = FROM_I2C_SLAVE(S35392_Slave, (i2c_slave*)i2c_create_slave(i2c, "S35392", 0x31));
	s->parent = dev;
	TRC_P_DBG("Slave:0x%x Parent:0x%x\n", s, dev);
	s = FROM_I2C_SLAVE(S35392_Slave, (i2c_slave*)i2c_create_slave(i2c, "S35392", 0x32));
	s->parent = dev;
	TRC_P_DBG("Slave:0x%x Parent:0x%x\n", s, dev);
	return 0;
}

static I2CSlaveInfo S35392_info = {
	.qdev.name = "S35392",
	.qdev.size = sizeof(S35392_Slave),
	.init = S35392_slave_init,
	.event = S35392_event,
	.recv = S35392_recv,
	.send = S35392_send,
};

static void S35392_register_devices(void)
{
	i2c_register_slave(&S35392_info);
}

device_init(S35392_register_devices)
