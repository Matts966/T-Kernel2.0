#include "sysbus.h"
#include "i2c.h"


typedef struct {
	SysBusDevice busdev;
	i2c_bus *bus;
	qemu_irq irq;

	int			status;
	int			step;

	uint16_t	address;

	uint16_t	iic;		/* Shift���W�X�^(Recv/Send)	*/
	uint16_t	iicc;		/* Control���W�X�^			*/
	uint16_t	sva;		/* Slave Address			*/
	uint16_t	iiccl;		/* Clock�I�����W�X�^		*/
	uint16_t	iicse;		/* ��ԃ��W�X�^				*/
	uint16_t	iicf;		/* Flag���W�X�^				*/
}em1_i2c_state;

#define I2C_IDLE		0
#define I2C_BUSY		1

#define I2C_ENABLE		0x0080

#define IICC_IICE		0x0080
#define IICC_LREL		0x0040
#define IICC_WREL		0x0020		/* Wait����			*/
#define IICC_SPIE		0x0010		/* Stop���荞�݋���	*/
#define IICC_ACKE		0x0004
#define IICC_STT		0x0002
#define IICC_SPT		0x0001

#define IICSE_MSTS		0x8000
#define IICSE_ALD		0x4000
#define IICSE_EXC		0x2000
#define IICSE_COI		0x1000
#define IICSE_TRC		0x0800
#define IICSE_ACKD		0x0400
#define IICSE_STD		0x0200
#define IICSE_SPD		0x0100

#define IICF_STCF		0x0080
#define IICF_IICBSY		0x0040
#define IICF_STCEN		0x0002
#define IICF_IICRSV		0x0001

#define DEBUG_I2C			0
#ifndef I2C_P_DBG
#if DEBUG_I2C
#define I2C_P_DBG(fmt, ...) printf("I2C:%s:%d " fmt, __FUNCTION__, __LINE__, ## __VA_ARGS__)
#else
#define I2C_P_DBG(fmt, ...) ((void)0)
#endif
#endif


static uint32_t em1_i2c_read(void *opaque, target_phys_addr_t offset)
{
	em1_i2c_state *s = (em1_i2c_state *)opaque;
	uint32_t	 ret = 0;

	offset = offset >> 2;
	I2C_P_DBG("offset:%x\n", offset);
	switch (offset)
	{
	case 0:						/* IIC */
		ret = s->iic;
		break;
	case 2:
		ret = s->iicc;
		break;
	case 3:
		ret = s->sva;
		break;
	case 4:
		ret = s->iiccl;
		break;
	case 7:
		ret = s->iicse;
		break;
	case 10:
		ret = s->iicf;
		break;
	default:
		hw_error("em1_i2c_read: Bad offset 0x%x\n", (int)offset);
		return 0;
	}

	I2C_P_DBG("iic:%x iicc:%x  sva:%x iiccl:%x iicse:%x iicf:%x\n", 
			  s->iic, s->iicc, s->sva, s->iiccl, s->iicse, s->iicf);
	I2C_P_DBG("Ret:%x\n", ret);
	return ret;
}

static void em1_i2c_update(em1_i2c_state *s)
{
	qemu_set_irq(s->irq, 1);
}

static void em1_i2c_write(void *opaque, target_phys_addr_t offset,
								uint32_t value)
{
	em1_i2c_state *s = (em1_i2c_state *)opaque;
	int ret = 0;

	offset = offset >> 2;
	I2C_P_DBG("offset:%d value:%x\n", offset, value);
	switch (offset)
	{
	case 0:				/* IIC */
		if (0 == (s->iicc & I2C_ENABLE))
			break;

		/* Wait���� */
		s->iicc &= ~(IICC_WREL);

		if (0 == s->step)
		{
			s->address = value >> 1;					/* Slave Address */

			s->iicse &= ~IICSE_TRC;						/* IISCE_TRC�N���A */
			if (s->iicse & IICSE_MSTS)					/* Master */
			{
				s->iicse |= ((value & 1) ^ 1) << 11;	/* IISCE_TRC�Z�b�g */
				I2C_P_DBG("address:0x%02x\n", s->address);
				if (0 == i2c_start_transfer(s->bus, s->address, 0 == (s->iicse & IICSE_TRC)))
					s->iicse |= IICSE_ACKD;
				em1_i2c_update(s);
			}
			else										/* Slave */
			{
				s->iicse |= (value & 1) << 11;			/* IISCE_TRC�Z�b�g */
			}

			s->step += 1;
		}
		else
		{
			if (i2c_send(s->bus, value) >= 0)			/* �f�[�^���M */
				s->iicse |= IICSE_ACKD;
			em1_i2c_update(s);
		}
		break;

	case 2:				/* IICC */
		s->iicc = value;

		if (0 == (value & IICC_IICE))
		{
			if (s->iicf & IICF_STCEN)
				s->iicf &= ~IICF_IICBSY;
			else
				s->iicf |= IICF_IICBSY;
			s->iicf &= ~IICF_STCF;
			s->iicc &= ~(IICC_STT | IICC_SPT);
			if (s->iicf & IICF_IICRSV)
				s->iicf | IICF_STCF;
			s->iicse &= ~(IICSE_MSTS | IICSE_EXC | IICSE_COI | IICSE_TRC | IICSE_ACKD);
			s->iicse &= ~(IICSE_STD);
		}
		if (value & IICC_LREL)
		{
			s->iicc &= ~(IICC_STT | IICC_SPT);
			if (s->iicf & IICF_IICRSV)
				s->iicf | IICF_STCF;
			s->iicse &= ~(IICSE_MSTS | IICSE_EXC | IICSE_COI | IICSE_TRC | IICSE_ACKD);

			s->iicc &= ~(IICC_LREL);
		}
		if (value & IICC_WREL)					/* ��M���[�h */
		{	/* Wait���� */
			s->iicc |= IICC_WREL;
			if (s->iicc & IICC_ACKE)
			{
				ret = i2c_recv(s->bus);			/* �f�[�^��M */
				if (ret >= 0)
				{
					s->iic = ret;
					em1_i2c_update(s);
				}
			}
			else {
				em1_i2c_update(s);
			}
			s->iicc &= ~IICC_WREL;
		}
		if (value & IICC_STT)
		{	/* Start Condition ���� */
			s->iicse |= IICSE_MSTS;
			s->iicf |= IICF_IICBSY;
			s->iicf &= ~IICF_STCF;
			s->iicf &= ~IICF_IICRSV;
			//			i2c_start_transfer(s->bus, s->sva, 0 == (s->iicse & IICSE_SEND));
		}
		if (value & IICC_SPT)
		{
			s->step = 0;
			i2c_end_transfer(s->bus);
			s->iicf &= ~IICF_IICBSY;
			s->iicse |= IICSE_SPD;
			if (s->iicc & IICC_SPIE)
				em1_i2c_update(s);
		}
		break;
		
	case 3:				/* SVA */
		s->sva = value;
		break;

	case 4:				/* IICCL */
		s->iiccl = value;
		break;

	case 7:				/* IICSE */
		s->iicse = value;
		break;
		
	case 10:			/* IICF */
		s->iicf = value;
		break;
	
	default:
		hw_error("em1_i2c_write: Bad offset 0x%x\n", (int)offset);
	}

	I2C_P_DBG("iic:%x iicc:%x  sva:%x iiccl:%x iicse:%x iicf:%x\n", 
			  s->iic, s->iicc, s->sva, s->iiccl, s->iicse, s->iicf);
}

static void em1_i2c_reset(em1_i2c_state *s)
{
	s->iic = 0;
	s->iicc = 0;
	s->sva = 0;
	s->iiccl = 0;
	s->iicse = 0;
	s->iicf = 0;

	I2C_P_DBG("iic:%x iicc:%x  sva:%x iiccl:%x iicse:%x iicf:%x\n", 
			  s->iic, s->iicc, s->sva, s->iiccl, s->iicse, s->iicf);
}

static CPUReadMemoryFunc * const em1_i2c_readfn[] = {
   em1_i2c_read,
   em1_i2c_read,
   em1_i2c_read
};

static CPUWriteMemoryFunc * const em1_i2c_writefn[] = {
   em1_i2c_write,
   em1_i2c_write,
   em1_i2c_write
};

static void em1_i2c_save(QEMUFile *f, void *opaque)
{
	em1_i2c_state *s = (em1_i2c_state *)opaque;

	qemu_put_be32(f, s->iic);
	qemu_put_be32(f, s->iicc);
	qemu_put_be32(f, s->sva);
	qemu_put_be32(f, s->iiccl);
	qemu_put_be32(f, s->iicse);
	qemu_put_be32(f, s->iicf);

	I2C_P_DBG("iic:%x iicc:%x  sva:%x iiccl:%x iicse:%x iicf:%x\n", 
			  s->iic, s->iicc, s->sva, s->iiccl, s->iicse, s->iicf);
}

static int em1_i2c_load(QEMUFile *f, void *opaque, int version_id)
{
	em1_i2c_state *s = (em1_i2c_state *)opaque;

	if (version_id != 1)
		return -EINVAL;

	s->iic = qemu_get_be32(f);
	s->iicc = qemu_get_be32(f);
	s->sva = qemu_get_be32(f);
	s->iiccl = qemu_get_be32(f);
	s->iicse = qemu_get_be32(f);
	s->iicf = qemu_get_be32(f);

	I2C_P_DBG("iic:%x iicc:%x  sva:%x iiccl:%x iicse:%x iicf:%x\n", 
			  s->iic, s->iicc, s->sva, s->iiccl, s->iicse, s->iicf);
	return 0;
}

static int em1_i2c_init(SysBusDevice * dev)
{
	em1_i2c_state *s = FROM_SYSBUS(em1_i2c_state, dev);
	int iomemtype;

	sysbus_init_irq(dev, &s->irq);
	s->bus = i2c_init_bus(&dev->qdev, "i2c");

	iomemtype = cpu_register_io_memory(em1_i2c_readfn,
									   em1_i2c_writefn, s);
	sysbus_init_mmio(dev, 0x100, iomemtype);

	/* ??? For now we only implement the master interface. */
	em1_i2c_reset(s);
	register_savevm("em1_i2c", -1, 1, em1_i2c_save, em1_i2c_load, s);

	I2C_P_DBG("iic:%x iicc:%x  sva:%x iiccl:%x iicse:%x iicf:%x\n", 
			  s->iic, s->iicc, s->sva, s->iiccl, s->iicse, s->iicf);
	return 0;
}

static void em1i2c_register_devices(void)
{
	sysbus_register_dev("em1i2c", sizeof(em1_i2c_state), em1_i2c_init);
}

device_init(em1i2c_register_devices)

