/*
 * QEMU touch panel implement.
 *
 * Copyright (C) 2011 Lei Tan <lei.tan@collab.ubin.jp>
 * Copyright (C) 2006 Fabrice Bellard
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include "qemu-common.h"
#include "qemu-option.h"
#include "qemu-config.h"
#include "tp.h"

static QemuOpts *tp_opts = NULL;

void tp_init(const char* arg){
	tp_opts = qemu_opts_parse(&qemu_tp_opts, arg, NULL);
}

int tp_get_number(const char* name){
	int data = 0;
	
	if(tp_opts){
		if(strncmp(name, "xmin", 4) == 0){
			data = qemu_opt_get_number(tp_opts, name, 64);
		}
		else if(strncmp(name, "xmax", 4) == 0){
			data = qemu_opt_get_number(tp_opts, name, 944);
		}
		else if(strncmp(name, "ymin", 4) == 0){
			data = qemu_opt_get_number(tp_opts, name, 80);
		}
		else if(strncmp(name, "ymax", 4) == 0){
			data = qemu_opt_get_number(tp_opts, name, 912);
		}
		else if(strncmp(name, "xchg", 4) == 0){
			data = qemu_opt_get_bool(tp_opts, name, 0);
		}
		else{
			data = qemu_opt_get_number(tp_opts, name, 0);
		}
	}
	else{
		if(strncmp(name, "xmin", 4) == 0){
			data = 64;
		}
		else if(strncmp(name, "xmax", 4) == 0){
			data = 944;
		}
		else if(strncmp(name, "ymin", 4) == 0){
			data = 80;
		}
		else if(strncmp(name, "ymax", 4) == 0){
			data = 912;
		}
		else{
			data = 0;
		}
	}

	return data;
}